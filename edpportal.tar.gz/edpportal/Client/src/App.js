import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import { HelmetProvider, Helmet } from "react-helmet-async";
import Landingpage from "./pages/landingpage";
import Calendar from "./pages/calendar";
import BudgetDashboard from "./pages/platform/budget";
import Ec2 from './pages/platform/ec2'
import Contact from './pages/contact';
import About from './pages/about';
import Calls from './pages/calls';
import Help from './pages/help';
import Ticket from './pages/ticket';
import Edpdataset from './pages/edpdataset';
import Edpdq from './pages/edpdq';
// import Marketingdq from './pages/marketingdq';
import Dqmetrics from './pages/dqmetrics';
import S3 from './pages/platform/s3';
import RDS from './pages/platform/rds';
import Resource from './pages/platform/resources';
import AMI_and_Snapshot from './pages/platform/amisnapshot';
import PrivateRoute from "./auth";
import { ToastContainer } from "react-toastify";
import { useMsalAuthentication, AuthenticatedTemplate, UnauthenticatedTemplate } from '@azure/msal-react';
import { InteractionType } from '@azure/msal-browser';
import RequestInterceptor from './interceptor';
import './style/App.css';
import Workflowsummary from './pages/workflowsummary';
import Workflowstatus from './pages/workflowstatus';

function App() {
  useMsalAuthentication(InteractionType.Redirect);
  return (
    <HelmetProvider>
      <Helmet
        titleTemplate="EDP"
        defaultTitle="EDP"
      />
      <AuthenticatedTemplate>
        <RequestInterceptor>
          <Router>
            <Routes>
              <Route path="/" element={<Landingpage/>} />
              <Route exact path='/platform/budget' element={<PrivateRoute path='/platform/budget'> <BudgetDashboard/></PrivateRoute>}/>
              <Route exact path='/platform/ec2' element={<PrivateRoute path='/platform/ec2'> <Ec2/></PrivateRoute>}/>
              <Route exact path='/platform/s3' element={<PrivateRoute path='/platform/s3'> <S3/></PrivateRoute>}/>
              <Route exact path='/platform/rds' element={<PrivateRoute path='/platform/rds'> <RDS/></PrivateRoute>}/>
              <Route exact path='/platform/resource' element={<PrivateRoute path='/platform/resource'> <Resource/></PrivateRoute>}/>
              {/* <Route exact path='/platform/ami' element={<PrivateRoute path='/platform/ami'> <AMI/></PrivateRoute>}/> */}
              <Route exact path='/platform/ami&snapshot' element={<PrivateRoute path='/platform/ami&snapshot'> <AMI_and_Snapshot/></PrivateRoute>}/>
              <Route exact path='/contact' element={<PrivateRoute path='/contact'> <Contact/></PrivateRoute>}/>
              <Route exact path='/calendar' element={<PrivateRoute path='/calendar'> <Calendar/></PrivateRoute>}/>
              <Route exact path='/calls' element={<PrivateRoute path='/calls'> <Calls/></PrivateRoute>}/>
              <Route exact path='/ticket' element={<PrivateRoute path='/ticket'> <Ticket/></PrivateRoute>}/>
              <Route exact path='/workflowsummary' element={<PrivateRoute path='/workflowsummary'> <Workflowsummary/></PrivateRoute>}/>
              <Route exact path='/workflowstatus' element={<PrivateRoute path='/workflowstatus'> <Workflowstatus/></PrivateRoute>}/>
              <Route path="/about" element={<About/> } />
              <Route path="/help" element={<Help/> } />
              <Route path="/edpdataset" element={<Edpdataset/> } />
              <Route path="/edpdq" element={<Edpdq/> } />
              {/* <Route path="/marketingdq" element={<Marketingdq/> } /> */}
              <Route path="/dqmetrics" element={<Dqmetrics/> } />
            </Routes>
          </Router>
          </RequestInterceptor>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <Router>
          <Routes>
            <Route path="/" element={<Landingpage/>} />
            <Route exact path='/platform/budget' element={<PrivateRoute path='/platform/budget'> <BudgetDashboard/></PrivateRoute>}/>
            <Route exact path='/platform/ec2' element={<PrivateRoute path='/platform/ec2'> <Ec2/></PrivateRoute>}/>
            <Route exact path='/platform/s3' element={<PrivateRoute path='/platform/s3'> <S3/></PrivateRoute>}/>
            <Route exact path='/platform/rds' element={<PrivateRoute path='/platform/rds'> <RDS/></PrivateRoute>}/>
            <Route exact path='/platform/resource' element={<PrivateRoute path='/platform/resource'> <Resource/></PrivateRoute>}/>
            <Route exact path='/platform/ami&snapshot' element={<PrivateRoute path='/platform/ami&snapshot'> <AMI_and_Snapshot/></PrivateRoute>}/>
            <Route exact path='/contact' element={<PrivateRoute path='/contact'> <Contact/></PrivateRoute>}/>
            <Route exact path='/calendar' element={<PrivateRoute path='/calendar'> <Calendar/></PrivateRoute>}/>
            <Route exact path='/calls' element={<PrivateRoute path='/calls'> <Calls/></PrivateRoute>}/>
            <Route exact path='/ticket' element={<PrivateRoute path='/ticket'> <Ticket/></PrivateRoute>}/>
            <Route exact path='/workflowsummary' element={<PrivateRoute path='/workflowsummary'> <Workflowsummary/></PrivateRoute>}/>
            <Route exact path='/workflowstatus' element={<PrivateRoute path='/workflowstatus'> <Workflowstatus/></PrivateRoute>}/>
            <Route path="/about" element={<About/> } />
            <Route path="/help" element={<Help/> } />
            <Route path="/edpdataset" element={<Edpdataset/> } />
            <Route path="/edpdq" element={<Edpdq/> } />
            {/* <Route path="/marketingdq" element={<Marketingdq/> } /> */}
            <Route path="/dqmetrics" element={<Dqmetrics/> } />
          </Routes>
        </Router>
      </UnauthenticatedTemplate>
      
      <ToastContainer autoClose={2000} />
    </HelmetProvider>
  )
}

export default App;
