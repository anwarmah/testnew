const menu = [
    {
      id    : 'home',
      title : 'Home',
      url   :'#'
    },
    {
        id    : 'platform',
        title : 'Platform',
        url   :'#'
      },
      {
        id    : 'support',
        title : 'Support',
        url   :'#'
      },
      {
        id    : 'about',
        title : 'About',
        url   :'#'
      },
  ];
  export default menu;
  