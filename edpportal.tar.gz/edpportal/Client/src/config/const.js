export const eventStructure = {
    contact : {
        _id : ''
    },
    team: '',
    start: '',
    end: '',
    type: '',
    _id: ''
}
export const contactStructure = {
    name: '',
    ntid: '',
    email: '',
    phone: '',
    timezone: '',
    location:'',
    _id: ''
}

export const edpdqStructure = {
    table_name: '',
    column_name: '',
    rule_name: '',
    custom_query_check: '',
    description: '',
    _id: ''
}

export const marketingdqStructure = {
    table_name: '',
    column_name: '',
    rule_name: '',
    custom_query_check: '',
    description: '',
    _id: ''
}

export const callStructure = {
    contact : {
        _id : ''
    },
    description: '',
    type : '',
    start: '',
    end  : '',
    status: '',
    _id: ''
}

export const headerConf = {
    headers:{
        "X-CSRF-TOKEN":"KL6lJ5ycmqwJgAsop78o5zhN",
        "name": "session",
        "expires": new Date()
    }
}
export const faqStructure = {
    title : "",
    createdAt: "",
    description: "",
    _id: ""
}

export const edpdatasetStructure = {
    profile : "",
    table_name: "",
    description: "",
    link: "",
    _id: ""
}

export const ticketStructure = {
    _id : "",
    priority: "",
    name: "",
    year: "",
    month: "",
    value:""
}

export const dqmetricStructure = {
    check_type: '',
    rule_cd: '',
    product_nm: '',
    database_nm: '',
    table_nm: '',
    field_nm: '',
    system_nm: '',
    job_name: '',
    dq_type_nm: '',
    Bucket_Size: '',
    domain_owner: '',
    alert_owner: '',
    trns_dt_key: '',
    dqi_indicator: '',
    dq_check_description: '',
    aggr_key: '',
    calc_type: '',
    metric_1_value: '',
    metric_2_value: '',
    calc_value: '',
    thrshld_cd: '',
    inserted_ts: '',
    inserted_by: '',
    _id: ''
}

export const workflowsummaryStructure = {
    workflow_name: '',
    start_time: '',
    average_runtime: '',
    run_frequency: '',
    job_dependency: '',
    source_type: '',
    source_connection: '',
    intermediate_table: '',
    ingestion_method: '',
    target: '',
    _id: ''
}

export const workflowstatusStructure = {
    workflow_name: '',
    start_time: '',
    average_runtime: '',
    frequency: '',
    job_dependency: '',
    duration: '',
    status: '',
    sla: '',
    _id: ''
}

export const s3Structure = {
    s3_bucket_name: '',
    Bucket_Size: '',
    s3_last_modified_name: '',
    s3_last_modified_date: '',
    _id: ''
}

export const rdsStructure = {
    DB_Instance_Name: '',
    DB_Type: '',
    DB_Storage: '',
    DB_engine: '',
    DB_Engine_Address: '',
    DB_Engine_Port: '',
    DB_Instance_Status: '',
    Preferred_Backup_Window: '',
    Backup_Retention_Period: '',
    Availability_Zone: '',
    Preferred_Maintenance_Window: '',
    _id: ''
}

export const amiStructure = {
    Region: '',
    Snapshot_ID: '',
    Snapshot_Volume: '',
    _id: ''
}

export const snapshotStructure = {
    Region: '',
    Instance_AMI: '',
    Architecture: '',
    Creation_Date: '',
    Image_Location: '',
    Platform_Details: '',
    State: '',
    _id: ''
}

export const months = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"];