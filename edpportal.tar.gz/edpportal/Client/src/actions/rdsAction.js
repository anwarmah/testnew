import { createSlice } from '@reduxjs/toolkit';
//import { toast } from "react-toastify";
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {setting, conf} from '../config/config';
export const slice = createSlice({
  name: 'rdsData',
  initialState: {
      contacts: []
  },
  reducers: {
    getAllrdsData: (state, action) => {
      state.rds = action.payload;
    },
    setRdsData: (state, action) => {
      state.rds = [...state.rds, action.payload];
    }
  },
});

export const {getAllrdsData, setRdsData} = slice.actions;

export const getAllrds = () => dispatch =>{
    axios.post(`${conf.api_url}/rds/getAllrds`)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            dispatch(getAllrdsData(data));
        })
        .catch(() => {
    });
}

export const selectRds = state => state.rdsData.rds;

export default slice.reducer;