import { createSlice } from '@reduxjs/toolkit';
//import { toast } from "react-toastify";
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {setting, conf} from '../config/config';
export const slice = createSlice({
  name: 'amiData',
  initialState: {
      contacts: []
  },
  reducers: {
    getAllec2amiData: (state, action) => {
      state.ec2Ami = action.payload;
    },
    setAmiData: (state, action) => {
      state.ec2Ami = [...state.ec2Ami, action.payload];
    }
  },
});

export const {getAllec2amiData, setAmiData} = slice.actions;

export const getAllec2ami = () => dispatch =>{
    axios.post(`${conf.api_url}/ami/getAllec2ami`)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            dispatch(getAllec2amiData(data));
        })
        .catch(() => {
    });
}

export const selectAmi = state => state.ec2AmiData.ec2Ami;

export default slice.reducer;