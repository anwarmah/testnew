import { createSlice } from '@reduxjs/toolkit';
//import { toast } from "react-toastify";
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {setting, conf} from '../config/config';
export const slice = createSlice({
  name: 's3Data',
  initialState: {
      contacts: []
  },
  reducers: {
    getAlls3sizeData: (state, action) => {
      state.s3BucketSize = action.payload;
    },
    setS3Data: (state, action) => {
      state.s3BucketSize = [...state.s3BucketSize, action.payload];
    }
  },
});

export const {getAlls3sizeData, setS3Data} = slice.actions;

export const getAlls3size = () => dispatch =>{
    axios.post(`${conf.api_url}/s3/getAlls3size`)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            dispatch(getAlls3sizeData(data));
        })
        .catch(() => {
    });
}

export const selectS3 = state => state.s3BucketSizeData.s3BucketSize;

export default slice.reducer;