import axios from 'axios';
import {conf} from '../config/config';

export function getResourceCount(res) {
    var data;
    axios.post(`${conf.api_url}/resource/getAllResourceCount`)
        .then(response => {
            res({data: response});
        })
        .catch(() => {
    });
    return data;
  }
