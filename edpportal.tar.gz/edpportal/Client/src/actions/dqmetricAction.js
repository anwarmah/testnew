import { createSlice } from '@reduxjs/toolkit';
import { toast } from "react-toastify";
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {setting, conf} from '../config/config';

export const slice = createSlice({
    name: 'dqmetricData',
    initialState: {
        dqmetrics: [],
        chartData: [],
        dqichartData: [],
        dqichartcountData: []
    },
    reducers: {
        setAllData: (state, action) => {
            state.dqmetrics = action.payload;
        },
        setDqmetricData: (state, action) => {
            state.dqmetrics = [...state.dqmetrics, action.payload];
        },
        setChartData: (state, action)=>{
            state.chartData = action.payload;
        },
        setDqiChartData: (state, action)=>{
            state.dqichartData = action.payload;
        },
        setDqiChartCountData: (state, action)=>{
            state.dqichartcountData = action.payload;
        }
    },
});

export const { setAllData, setDqmetric, setChartData, setDqiChartData, setDqiChartCountData} = slice.actions;

// The function below is called a thunk and allows us to perform async logic. It
// can be dispatched like a regular action: `dispatch(incrementAsync(10))`. This
// will call the thunk with the `dispatch` function as the first argument. Async
// code can then be executed and other actions can be dispatched
export const getAll = (param) => dispatch =>{
    axios.post(`${conf.api_url}/dqmetric/getAll`, param)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            dispatch(setAllData(data));
        })
        .catch(() => {
        });
}

export const delDqmetric= (id) => dispatch=> {
    axios.post(`${conf.api_url}/dqmetric/delDqmetric`, {id : id})
        .then(response => {
            if(response.data.status === "Success"){
                dispatch(getAll());
                toast.success("success");
            }else{
                toast.warn("Error");
            }
        })
        .catch(() => {
        });
}

export const addDqmetric = (params) => dispatch => {
    axios.post(`${conf.api_url}/dqmetric/addDqmetric`,params)
        .then(response => {
            if(response.data.status === "Success"){
                dispatch(getAll());
                toast.success("success");
            }else{
                var data = jwt_decode(response.data.data, setting.secret);
                toast.error(data);
            }
        })
        .catch(()=>{
            console.log("error");
        })
}

export const getChartData = (param) =>dispatch =>{
    axios.post(`${conf.api_url}/dqmetric/getStatistic`,param)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            if(response.data.status === "Success"){
                dispatch(setChartData(data));
            }else{
                toast.error(data);
            }
        })
        .catch(()=>{
            console.log("error");
        })
}

export const getDqiChartCountData = (param) =>dispatch =>{
    axios.post(`${conf.api_url}/dqmetric/getDQICount`,param)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            if(response.data.status === "Success"){
                dispatch(setDqiChartCountData(data));
            }else{
                toast.error(data);
            }
        })
        .catch(()=>{
            console.log("error");
        })
}

export const getDqiChartData = (param) =>dispatch =>{
    axios.post(`${conf.api_url}/dqmetric/getDqi`,param)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            if(response.data.status === "Success"){
                dispatch(setDqiChartData(data));
            }else{
                toast.error(data);
            }
        })
        .catch(()=>{
            console.log("error");
        })
}

// The function below is called a selector and allows us to select a value from
// the state. Selectors can also be defined inline where they're used instead of
// in the slice file. For example: `useSelector((state) => state.counter.value)`
export const selectDqmetric = state => state.dqmetricsData.dqmetrics;
export const selectChartData =  state => state.dqmetricsData.chartData;
export const selectDqiChartData =  state => state.dqmetricsData.dqichartData;
export const selectDqiChartCountData =  state => state.dqmetricsData.dqichartcountData;

export default slice.reducer;