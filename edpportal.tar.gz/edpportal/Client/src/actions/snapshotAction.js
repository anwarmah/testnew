import { createSlice } from '@reduxjs/toolkit';
//import { toast } from "react-toastify";
import axios from 'axios';
import jwt_decode from 'jwt-decode';
import {setting, conf} from '../config/config';
export const slice = createSlice({
  name: 'snapshotData',
  initialState: {
      contacts: []
  },
  reducers: {
    getAllsnapshotData: (state, action) => {
      state.snapshot = action.payload;
    },
    setSnapshotData: (state, action) => {
      state.snapshot = [...state.snapshot, action.payload];
    }
  },
});

export const {getAllsnapshotData, setSnapshotData} = slice.actions;

export const getAllsnapshot = () => dispatch =>{
    axios.post(`${conf.api_url}/snapshot/getAllsnapshot`)
        .then(response => {
            var data = jwt_decode(response.data.data, setting.secret);
            dispatch(getAllsnapshotData(data));
        })
        .catch(() => {
    });
}

export const selectSnapshot = state => state.snapshotData.snapshot;

export default slice.reducer;