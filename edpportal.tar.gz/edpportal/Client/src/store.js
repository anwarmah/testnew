import { configureStore } from '@reduxjs/toolkit';
import EventReducer from './actions/eventAction';
import ContactReducer from './actions/contactAction';
import CallReducer from './actions/callAction';
import FaqReducer from './actions/faqAction';
import TicketReducer from './actions/ticketAction';
import AuthReducer from './actions/authAction';
import EdpdatasetReducer from './actions/edpdatasetAction';
import EdpdqReducer from './actions/edpdqAction';
import MarketingdqReducer from './actions/marketingdqAction';
import S3Reducer from './actions/s3Action';
import RdsReducer from './actions/rdsAction';
import AMIReducer from './actions/amiAction';
import SnapshotReducer from './actions/snapshotAction';
import DqmetricReducer from './actions/dqmetricAction';
import WorkflowsummaryReducer from './actions/workflowsummaryAction';
import WorkflowstatusReducer from './actions/workflowstatusAction';

export default configureStore({
    reducer: {
        eventsData: EventReducer,
        contactsData:ContactReducer,
        callsData: CallReducer,
        faqsData: FaqReducer,
        ticketsData : TicketReducer,
        edpdatasetsData: EdpdatasetReducer,
        edpdqsData: EdpdqReducer,
        marketingdqsData: MarketingdqReducer,
        authData: AuthReducer,
        s3BucketSizeData: S3Reducer,
        rdsData: RdsReducer,  
        ec2AmiData: AMIReducer,      
        snapshotData: SnapshotReducer,
        dqmetricsData: DqmetricReducer,
        workflowsummarysData: WorkflowsummaryReducer,
        workflowstatussData: WorkflowstatusReducer,
    },
});