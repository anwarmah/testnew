import {React} from 'react';
import {Box, Container, Typography,} from '@mui/material';

const Header = () =>{

    return(
        <div>
            <Box sx={{
                height : {lg:'351px', xs:'500px'},
                backgroundColor:'#f6f6f9',
                paddingTop:'156px',
                justifyContent:"space-between",
                alignItems:"stretch" }} >
                    <Container>
                        <Typography
                            textAlign={'center'}
                            fontWeight={'light'}
                        >
                            Who We Are
                        </Typography>
                        
                        <Typography
                            textAlign={'center'}
                            fontFamily={'PT Serif, Georgia, serif'}
                            fontWeight={'900'}
                            variant={'h2'}
                        >
                            Martech Engagement Data Platform
                        </Typography>
                    </Container>
            </Box>
        </div>
    );

}
export default Header;