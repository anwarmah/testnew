import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
// import {useDispatch } from 'react-redux';
import { toast, ToastContainer } from "react-toastify";
//import {rdsDataContext} from './content';

export default function RdsDialog(props) {

  // const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.DB_Instance_Name === ""){
      toast.error("DB Instance Name Required!");
    }else if(formData.DB_Type === ""){
      toast.error("DB Type Required!");
    }else if(formData.DB_Storage === ""){
      toast.error("DB Storage Name Required!");
    }else if(formData.DB_engine === ""){
      toast.error("DB Engine Required!");
    }else if(formData.DB_Engine_Address === ""){
      toast.error("DB Engine Address Required!");
    }else if(formData.DB_Engine_Port === ""){
      toast.error("DB Engine Port Required!");
    }else if(!formData.custom_query_check.match(validRegex)) {
      toast.error("Only Y or N allowed");  
    }else{
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>RDS Detail</DialogTitle>
        <DialogContent>
          <DialogContentText>
            RDS details
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="DB_Instance_Name"
            label="DB Instance Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Instance_Name}
            onChange={evt => { setFormData(f => ({ ...f, DB_Instance_Name: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_Type"
            label="DB Type"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Type}
            onChange={evt => { setFormData(f => ({ ...f, DB_Type: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_Storage"
            label="DB Storage Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Storage}
            onChange={evt => { setFormData(f => ({ ...f, DB_Storage: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_engine"
            label="DB Engine"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_engine}
            onChange={evt => { setFormData(f => ({ ...f, DB_engine: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_Engine_Address"
            label="DB Engine Address"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Engine_Address}
            onChange={evt => { setFormData(f => ({ ...f, DB_Engine_Address: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_Engine_Port"
            label="DB Enginer Port"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Engine_Port}
            onChange={evt => { setFormData(f => ({ ...f, DB_Engine_Port: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="DB_Instance_Status"
            label="DB Instance Status"
            type="text"
            fullWidth
            variant="standard"
            value={formData.DB_Instance_Status}
            onChange={evt => { setFormData(f => ({ ...f, DB_Instance_Status: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Preferred_Backup_Window"
            label="Preferred Backup Window"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Preferred_Backup_Window}
            onChange={evt => { setFormData(f => ({ ...f, Preferred_Backup_Window: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Backup_Retention_Period"
            label="Backup Retention Period"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Backup_Retention_Period}
            onChange={evt => { setFormData(f => ({ ...f, Backup_Retention_Period: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Availability_Zone"
            label="Availability Zone"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Availability_Zone}
            onChange={evt => { setFormData(f => ({ ...f, Availability_Zone: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Preferred_Maintenance_Window"
            label="Preferred Maintenance Window"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Preferred_Maintenance_Window}
            onChange={evt => { setFormData(f => ({ ...f, Preferred_Maintenance_Window: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}