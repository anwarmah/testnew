import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
// import { styled } from '@mui/material/styles';
import { 
    Box, 
    // IconButton,
    // Button,
    // Dialog,
    // DialogContent,
    // DialogActions,
    // DialogContentText,
    // DialogTitle,
    // Slide 
} from '@mui/material';

// import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import RdsDetail from './rdsDetail';

import { rdsStructure } from '../../../config/const';

import {getAllrds, selectRds} from '../../../actions/rdsAction';

// const Transition = React.forwardRef(function Transition(props, ref) {
//     return <Slide direction="up" ref={ref} {...props} />;
// });


const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
            borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
            '&:not(:last-child)': {
                borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
            alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
            background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAllrds());
    }, [])
    const rdsList = useSelector(selectRds);
    const [open, setOpen] = useState(false);
    // const [rdsData, setRdsData] = useState(rdsStructure);
    const [rdsData] = useState(rdsStructure);
    // const [dialogOpen, setDialogOpen] = useState(false);
    // const editS3Data=(value)=>{
    //     var data = value.rowData;
    //     setS3Data({...s3Data, 
    //         _id: data[0],
    //         s3_bucket_name: data[1],
    //         Bucket_Size: data[2],
    //         s3_last_modified_name: data[3],
    //         s3_last_modified_date: data[4]
    //     })
    //     setOpen(true)
    // }
    const rdsColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 'DB_Instance_Name',
            label: 'DB Instance Name',
            align: 'center'
        },
        { 
            name: 'DB_Type',
            label: 'DB Type',
            align: 'center'
        },
        {
            name: 'DB_Storage',
            label: 'DB Storage Name',
            align: 'center'
        },
        {
            name: 'DB_engine',
            label: 'DB Engine',
            align: 'center'
        },
        {
            name: 'DB_Engine_Address',
            label: 'DB Engine Address',
            align: 'center'
        },
        {
            name: 'DB_Engine_Port',
            label: 'DB Engine Port',
            align: 'center'
        },        
        { 
            name: 'DB_Instance_Status',
            label: 'DB Instance Status',
            align: 'center'
        },
        {
            name: 'Preferred_Backup_Window',
            label: 'Preferred Backup Window',
            align: 'center'
        },
        {
            name: 'Backup_Retention_Period',
            label: 'Backup Retention Period',
            align: 'center'
        },
        {
            name: 'Availability_Zone',
            label: 'Availability Zone',
            align: 'center'
        },
        {
            name: 'Preferred_Maintenance_Window',
            label: 'Preferred Maintenance Window',
            align: 'center'
        },           
        // {
        //     name: 'action',
        //     label: 'ACTION',
        //     align: 'center',
        //     options: {
        //         customBodyRender: (value, tableMeta, updateValue)  => {
        //             return (
        //                 <Box sx={{display:'flex', justifyContent:'left'}}>
        //                     <IconButton onClick = {()=>{editS3Data(tableMeta); setOpen(true)}} color="primary"><BorderColorSharpIcon/></IconButton>
        //                 </Box>
        //             );
        //         },
        //         filter: false
        //     },
           
            
        // },
    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,  
      };
    return(
        <Container maxWidth="lg" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={rdsList}
                        columns={rdsColumn}
                        options={options}
                        title={"RDS Bucket"}
                    />
                </ThemeProvider>
            </Box>
            <RdsDetail open={open} setOpen={setOpen} data = {rdsData}/>
        </Container>
    );
}
export default Content;
