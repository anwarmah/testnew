import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
// import {useDispatch } from 'react-redux';
import { toast, ToastContainer } from "react-toastify";
//import {s3BucketSizeDataContext} from './content';

export default function S3Dialog(props) {

  // const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.s3_bucket_name === ""){
      toast.error("Bucket Name Required!");
    }else if(formData.Bucket_Size === ""){
      toast.error("Bucket Size Required!");
    }else if(formData.s3_last_modified_name === ""){
      toast.error("Last Modified Name Required!");
    }else if(formData.s3_last_modified_date === ""){
      toast.error("Last Modified Date Required!");
    }else if(!formData.custom_query_check.match(validRegex)) {
      toast.error("Only Y or N allowed");  
    }else{
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>S3 Detail</DialogTitle>
        <DialogContent>
          <DialogContentText>
            S3 details
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="s3_bucket_name"
            label="Bucket Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.s3_bucket_name}
            onChange={evt => { setFormData(f => ({ ...f, s3_bucket_name: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Bucket_Size"
            label="Bucket Size"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Bucket_Size}
            onChange={evt => { setFormData(f => ({ ...f, Bucket_Size: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="s3_last_modified_name"
            label="Last Modified File Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.s3_last_modified_name}
            onChange={evt => { setFormData(f => ({ ...f, s3_last_modified_name: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="s3_last_modified_date"
            label="Last Modified File Date"
            type="text"
            fullWidth
            variant="standard"
            value={formData.s3_last_modified_date}
            onChange={evt => { setFormData(f => ({ ...f, s3_last_modified_date: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}