import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
// import { styled } from '@mui/material/styles';
import { 
    Box, 
    // IconButton,
    // Button,
    // Dialog,
    // DialogContent,
    // DialogActions,
    // DialogContentText,
    // DialogTitle,
    // Slide 
} from '@mui/material';

// import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import S3Detail from './s3Detail';

import { s3Structure } from '../../../config/const';

import {getAlls3size, selectS3} from '../../../actions/s3Action';

// const Transition = React.forwardRef(function Transition(props, ref) {
//     return <Slide direction="up" ref={ref} {...props} />;
// });


const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
               borderColor: '#d3d3d3',
            },
            head: {
              background: 'lightgrey',
              '&:not(:last-child)': {
                  borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
               alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
                background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // // height: undefined,
            },            
        },
    },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAlls3size());
    }, [])
    const s3List = useSelector(selectS3);
    const [open, setOpen] = useState(false);
    // const [s3Data, setS3Data] = useState(s3Structure);
    const [s3Data] = useState(s3Structure);
    const s3Column = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 's3_bucket_name',
            label: 'Bucket Name',
            align: 'center'
        },
        { 
            name: 'Bucket_Size',
            label: 'Bucket Size',
            align: 'center'
        },
        {
            name: 's3_last_modified_name',
            label: 'Last Modified File Name',
            align: 'center'
        },
        {
            name: 's3_last_modified_date',
            label: 'Last Modified File Date',
            align: 'center'
        },

    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,  
      };
    return(
        <Container maxWidth="lg" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={s3List}
                        columns={s3Column}
                        options={options}
                        title={"S3 Bucket"}
                    />
                </ThemeProvider>
            </Box>
            <S3Detail open={open} setOpen={setOpen} data = {s3Data}/>
        </Container>
    );
}
export default Content;
