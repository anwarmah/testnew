import React, {  useState, useEffect, createContext } from 'react';
import {
   Grid, Container, Box
} from '@mui/material';
import ResourceTable from './resourceTable';
import { getResourceCount } from '../../../actions/resourceAction';
import jwt_decode from 'jwt-decode';
import {setting} from '../../../config/config';

export const ResourceCountDataContext = createContext();

const Content = () =>{
  const [resourceCountdata, setResourceCountdata] = useState([]);

  useEffect(()=>{
    getResourceCount( res => {
      var data = jwt_decode(res.data.data, setting.secret);
      setResourceCountdata(data);
    });

  },[]);

    return(
      <ResourceCountDataContext.Provider value={{resourceCountdata}}>
        <Container maxWidth="lg"  sx={{marginTop:'30px', marginBottom:'30px'}}>
          <Box>
            <Grid container spacing={12}>
              <Grid item xs={12} lg={12}>
                <ResourceTable />
              </Grid>
            </Grid>
          </Box>
        </Container>
      </ResourceCountDataContext.Provider>
    );
}
export default Content;