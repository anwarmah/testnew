import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { toast, ToastContainer } from "react-toastify";


export default function SnapshotDialog(props) {

  // const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.Region === ""){
      toast.error("Region Name Required!");
    }else if(formData.Snapshot_ID === ""){
      toast.error("Snapshot ID Required!");
    }else if(formData.Snapshot_Volume === ""){
      toast.error("Snapshot Volume Required!");
    }else if(!formData.custom_query_check.match(validRegex)) {
      toast.error("Only Y or N allowed");  
    }else{
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>Snapshot Detail</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Snapshot details
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="Region"
            label="Region"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Region}
            onChange={evt => { setFormData(f => ({ ...f, Region: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Snapshot_ID"
            label="Snapshot ID"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Snapshot_ID}
            onChange={evt => { setFormData(f => ({ ...f, Snapshot_ID: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Snapshot_Volume"
            label="Snapshot Volume"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Snapshot_Volume}
            onChange={evt => { setFormData(f => ({ ...f, Snapshot_Volume: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}