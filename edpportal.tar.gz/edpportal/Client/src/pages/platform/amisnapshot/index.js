import React, { useEffect, useState } from 'react';
import Header from '../../header';
import Content from './content';
// import Footer from '../../footer';

const Amisummary = () =>{

    const [winheight, setHeight] = useState(0);
    useEffect(() => {
        setHeight(document.body.scrollHeight - 48);
    }, [])   
    return(
        <div style={{flexDirection: 'column', justifyContent:'space-between', alignItems:"stretch", flex: 1}}>
            <div style={{flex: 1, height: winheight+'px'}}>
                <Header subTitle={'AMI & Snapshot Details'} title={'Platform'}/>
                <Content />
            </div>
            {/* <div style={{flex: 1, height: winheight+'px'}}>
                <Header subTitle={'Snapshot Details'} title={'Platform'}/>
                <Content />
            </div>             */}
            <div style={{flex: 1}}>
            </div>
        </div>

    );
}
export default Amisummary;