import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';

import { 
    Box, 
} from '@mui/material';

import AmiDetail from './amiDetail';
import SnapshotDetail from './snapshotDetail';

import { amiStructure } from '../../../config/const';
import { snapshotStructure } from '../../../config/const';

import {getAllec2ami, selectAmi} from '../../../actions/amiAction';
import {getAllsnapshot, selectSnapshot} from '../../../actions/snapshotAction';
// import { getAllsnapshot } from '../../../actions';

const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
            borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
            '&:not(:last-child)': {
                borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
            alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
            background: 'lightgrey',
            },
        },
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAllec2ami());
        dispatch(getAllsnapshot());
    }, [])
    const amiList = useSelector(selectAmi);
    const snapshotList = useSelector(selectSnapshot);
    const [open, setOpen] = useState(false);

    const [amiData] = useState(amiStructure);
    const [snapshotData] = useState(snapshotStructure);
    const amiColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 'Region',
            label: 'Region',
            align: 'center'
        },
        { 
            name: 'Instance_AMI',
            label: 'Instance AMI',
            align: 'center'
        },
        {
            name: 'Architecture',
            label: 'Architecture',
            align: 'center'
        },
        {
            name: 'Creation_Date',
            label: 'Creation Date',
            align: 'center'
        },
        { 
            name: 'Image_Location',
            label: 'Image Location',
            align: 'center'
        },
        {
            name: 'Platform_Details',
            label: 'Platform Details',
            align: 'center'
        },
        {
            name: 'State',
            label: 'State',
            align: 'center'
        },
    ];
    const snapshotColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 'Region',
            label: 'Region',
            align: 'center'
        },
        { 
            name: 'Snapshot_ID',
            label: 'Snapshot ID',
            align: 'center'
        },
        {
            name: 'Snapshot_Volume',
            label: 'Snapshot Volume',
            align: 'center'
        },
    ];        
    const options = {
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,  
      };
    return(
        <Container maxWidth="lg" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={amiList}
                        columns={amiColumn}
                        options={options}
                        title={"AMI"}
                    />
                </ThemeProvider>
            </Box>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={snapshotList}
                        columns={snapshotColumn}
                        options={options}
                        title={"Snapshot"}
                    />
                </ThemeProvider>
            </Box>            
            <SnapshotDetail open={open} setOpen={setOpen} data = {snapshotData}/>
            <AmiDetail open={open} setOpen={setOpen} data = {amiData}/>
        </Container>
    );
}
export default Content;
