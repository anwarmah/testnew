import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { toast, ToastContainer } from "react-toastify";


export default function AmiDialog(props) {

  // const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.Region === ""){
      toast.error("Region Name Required!");
    }else if(formData.Instance_AMI === ""){
      toast.error("Instance AMI Required!");
    }else if(formData.Architecture === ""){
      toast.error("Architecture Name Required!");
    }else if(formData.Creation_Date === ""){
      toast.error("Creation Date Required!");
    }else if(formData.Image_Location === ""){
      toast.error("Image Location Required!");
    }else if(formData.Platform_Details === ""){
      toast.error("Platform Details Required!");
    }else if(formData.State === ""){
      toast.error("State Required!");
    }else if(!formData.custom_query_check.match(validRegex)) {
      toast.error("Only Y or N allowed");  
    }else{
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>AMI Detail</DialogTitle>
        <DialogContent>
          <DialogContentText>
            AMI details
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="Region"
            label="Region"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Region}
            onChange={evt => { setFormData(f => ({ ...f, Region: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Instance_AMI"
            label="Instance AMI"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Instance_AMI}
            onChange={evt => { setFormData(f => ({ ...f, Instance_AMI: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Architecture"
            label="Architecture"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Architecture}
            onChange={evt => { setFormData(f => ({ ...f, Architecture: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Creation_Date"
            label="Creation Date"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Creation_Date}
            onChange={evt => { setFormData(f => ({ ...f, Creation_Date: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Image_Location"
            label="Image Location"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Image_Location}
            onChange={evt => { setFormData(f => ({ ...f, Image_Location: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="Platform_Details"
            label="Platform Details"
            type="text"
            fullWidth
            variant="standard"
            value={formData.Platform_Details}
            onChange={evt => { setFormData(f => ({ ...f, Platform_Details: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="State"
            label="State"
            type="text"
            fullWidth
            variant="standard"
            value={formData.State}
            onChange={evt => { setFormData(f => ({ ...f, State: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}