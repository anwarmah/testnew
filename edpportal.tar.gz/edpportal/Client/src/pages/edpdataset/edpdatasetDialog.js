import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';

import { toast, ToastContainer } from "react-toastify";

import {useDispatch } from 'react-redux';
import {
  addEdpdataset
} from '../../actions/edpdatasetAction';

export default function EdpdatasetDialog(props) {

  const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    if(formData.description === ""){
      toast.error("DescriptionRequired!");  
    }else{
      dispatch(addEdpdataset(formData));
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>Add Dataset</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Add Dataset details
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="profile"
            label="PROFILE"
            type="text"
            fullWidth
            variant="standard"
            value={formData.profile}
            onChange={evt => { setFormData(f => ({ ...f, profile: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="table_name"
            label="TABLE NAME"
            type="text"
            fullWidth
            variant="standard"
            value={formData.table_name}
            onChange={evt => { setFormData(f => ({ ...f, table_name: evt.target.value})) }}
          />          
          <TextField
            required
            margin="dense"
            id="description"
            label="DESCRIPTION"
            type="text"
            fullWidth
            variant="standard"
            value={formData.description}
            onChange={evt => { setFormData(f => ({ ...f, description: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="link"
            label="Link"
            type="text"
            fullWidth
            variant="standard"
            value={formData.link}
            onChange={evt => { setFormData(f => ({ ...f, link: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}