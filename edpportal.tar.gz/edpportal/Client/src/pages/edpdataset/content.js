import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import { 
    Box, 
    IconButton,
    Button,
    Dialog,
    DialogContent,
    DialogActions,
    DialogContentText,
    DialogTitle,
    Slide 
} from '@mui/material';

import DeleteIcon from '@mui/icons-material/Delete';
import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import EdpdatasetDialog from './edpdatasetDialog';

import { edpdatasetStructure } from '../../config/const';

import {getAll, delEdpdataset, selectEdpdataset} from '../../actions/edpdatasetAction';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const ColorButton = styled(Button)(({ theme }) => ({
    backgroundColor: '#E1F0FF',
    fontSize: '11px',
    paddingLeft: '10px',
    paddingRight: '10px',
    marginLeft: '15px',
    color:'#3699FF',
    '&:hover': {
        color: '#FFFFFF',
        backgroundColor: '#3699FF',
    },
    boxShadow: 'none'
}));

const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
                borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
                '&:not(:last-child)': {
                    borderRight: [[1, 'solid', '#c0c0c0']],
                },
            },
        },
        MuiTableSortLabel: {
            root: {
                alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
                background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAll());
    }, [])
    const edpdatasetList = useSelector(selectEdpdataset);
    const [open, setOpen] = useState(false);
    const [edpdatasetData, setEdpdatasetData] = useState(edpdatasetStructure);
    const [dialogOpen, setDialogOpen] = useState(false);
    const editEdpdatasetData=(value)=>{
        var data = value.rowData;
        setEdpdatasetData({...edpdatasetData, 
            _id: data[0],
            profile: data[1],
            table_name: data[2],
            description: data[3],
            link:data[4]
        })
        setOpen(true)
    }
    const deleteEdpdataset =(value) =>{
        var data = value.rowData;
        setEdpdatasetData({...edpdatasetData, 
            _id: data[0],
            profile: data[1],
            table_name: data[2],
            description: data[3],
            link:data[4]
        })
        setDialogOpen(true);
    }
    const edpdatasetColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },{ 
            name: 'profile',
            label: 'PROFILE',
            align: 'center'
        },{ 
            name: 'table_name',
            label: 'TABLE_NAME',
            align: 'center',
            options: {
                customBodyRender:(value, tableMeta, updateValue)=> {
                    return <a href={tableMeta.rowData[4]} target="_blank">{value}</a>
                }
            }
        },{
            name: 'description',
            label: 'DESCRIPTION',
            align: 'center',
        },{ 
            name: 'link',
            options:{
                display: false,
                sort: false,
                viewColumns: false,
                filter: false
            }            
        },{
            name: 'action',
            label: 'ACTION',
            align: 'center',
            options: {
                customBodyRender: (value, tableMeta, updateValue)  => {
                    return (
                        <Box sx={{display:'flex', justifyContent:'left'}}>
                            <IconButton onClick = {()=>{editEdpdatasetData(tableMeta); setOpen(true)}} color="primary"><BorderColorSharpIcon/></IconButton>
                            <IconButton onClick = {()=>{deleteEdpdataset(tableMeta)}} color="primary"><DeleteIcon/></IconButton>
                        </Box>
                    );
                },
                filter: false
            },
           
            
        },
    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,
        customToolbar: () => {
            return (
                <ColorButton onClick={()=>{setEdpdatasetData(edpdatasetStructure); setOpen(true)}}>
                    Add Dataset
                </ColorButton>
            );
        },
      };
    return(
        <Container maxWidth="xxl" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={edpdatasetList}
                        columns={edpdatasetColumn}
                        options={options}
                        title={"EDP Dataset"}
                    />
                </ThemeProvider>
            </Box>
            <EdpdatasetDialog open={open} setOpen={setOpen} data = {edpdatasetData}/>
            <Dialog
                open={dialogOpen}
                TransitionComponent={Transition}
                keepMounted
                onClose={()=> {setDialogOpen(false)}}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>Confirm Dialog</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-slide-description">
                        Do you want to delete it? Once you delete it, you can't recovery again
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button  sx={{background: "#F64E60", color: "#ffff", marginRight:"20px",'&:hover': { background: "#F64E60",}}} onClick={()=>{dispatch(delEdpdataset(edpdatasetData._id)); setDialogOpen(false)}}>Agree</Button>
                    <Button onClick={()=>{setDialogOpen(false)}}>Disagree</Button>
                    
                </DialogActions>
            </Dialog>
        </Container>
    );
}
export default Content;
