import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { toast, ToastContainer } from "react-toastify";


import {useDispatch } from 'react-redux';
import {
  addWorkflowsummary
} from '../../actions/workflowsummaryAction';

export default function WorkflowsummaryDialog(props) {

  const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.workflow_name === ""){
      toast.error("Workflow Name Required!");
    }else if(formData.start_time === ""){
      toast.error("Start Time Required!");
    }else if(formData.average_runtime === ""){
      toast.error("Average Time Required!");
    }else if(formData.run_frequency === ""){
      toast.error("Run Frequency Required!");
    }else if(formData.job_dependency === ""){
      toast.error("Job Dependency Required!");
    }else if(formData.source_type === ""){
      toast.error("Source Type Required!");
    }else if(formData.source_connection === ""){
      toast.error("Source Connection Required!");
    }else if(formData.intermediate_table === ""){
      toast.error("Intermediate Table Required!");
    }else if(formData.ingestion_method === ""){
      toast.error("Ingestion Method Required!");
    }else if(formData.target === ""){
      toast.error("Target Required!");
    // }else if(formData.metric_2_value === ""){
    //   toast.error("Metric 2 Required!");
    }else{
      dispatch(addWorkflowsummary(formData));
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>Workflow Summary</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Workflow Summary
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="workflow_name"
            label="Workflow Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.workflow_name}
            onChange={evt => { setFormData(f => ({ ...f, workflow_name: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="start_time"
            label="Start Time"
            type="text"
            fullWidth
            variant="standard"
            value={formData.start_time}
            onChange={evt => { setFormData(f => ({ ...f, start_time: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="average_runtime"
            label="Average Time"
            type="text"
            fullWidth
            variant="standard"
            value={formData.average_runtime}
            onChange={evt => { setFormData(f => ({ ...f, average_runtime: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="run_frequency"
            label="Run Frequency"
            type="text"
            fullWidth
            variant="standard"
            value={formData.run_frequency}
            onChange={evt => { setFormData(f => ({ ...f, run_frequency: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="job_dependency"
            label="Job Dependency"
            type="text"
            fullWidth
            variant="standard"
            value={formData.job_dependency}
            onChange={evt => { setFormData(f => ({ ...f, job_dependency: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="source_type"
            label="Source Type"
            type="text"
            fullWidth
            variant="standard"
            value={formData.source_type}
            onChange={evt => { setFormData(f => ({ ...f, source_type: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="source_connection"
            label="Source Connection"
            type="text"
            fullWidth
            variant="standard"
            value={formData.source_connection}
            onChange={evt => { setFormData(f => ({ ...f, source_connection: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="intermediate_table"
            label="Intermediate Table"
            type="text"
            fullWidth
            variant="standard"
            value={formData.intermediate_table}
            onChange={evt => { setFormData(f => ({ ...f, intermediate_table: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="ingestion_method"
            label="Ingestion Method"
            type="text"
            fullWidth
            variant="standard"
            value={formData.ingestion_method}
            onChange={evt => { setFormData(f => ({ ...f, ingestion_method: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="target"
            label="Target"
            type="text"
            fullWidth
            variant="standard"
            value={formData.target}
            onChange={evt => { setFormData(f => ({ ...f, target: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}