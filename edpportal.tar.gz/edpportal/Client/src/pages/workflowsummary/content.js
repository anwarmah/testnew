import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import { 
    Box, 
    IconButton,
    Button,
    Dialog,
    DialogContent,
    DialogActions,
    DialogContentText,
    DialogTitle,
    Slide 
} from '@mui/material';

import DeleteIcon from '@mui/icons-material/Delete';
import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import WorkflowsummaryDialog from './workflowsummaryDialog';

import { workflowsummaryStructure } from '../../config/const';

import {getAll, delWorkflowsummary, selectWorkflowsummary} from '../../actions/workflowsummaryAction';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const ColorButton = styled(Button)(({ theme }) => ({
    backgroundColor: '#E1F0FF',
    fontSize: '11px',
    paddingLeft: '10px',
    paddingRight: '10px',
    marginLeft: '15px',
    color:'#3699FF',
    '&:hover': {
        color: '#FFFFFF',
        backgroundColor: '#3699FF',
    },
    boxShadow: 'none'
}));

const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
            borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
            '&:not(:last-child)': {
                borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
            alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
            background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAll());
    }, [])
    const workflowsummaryList = useSelector(selectWorkflowsummary);
    const [open, setOpen] = useState(false);
    const [workflowsummaryData, setWorkflowsummaryData] = useState(workflowsummaryStructure);
    const [dialogOpen, setDialogOpen] = useState(false);
    const editWorkflowsummaryData=(value)=>{
        var data = value.rowData;
        setWorkflowsummaryData({...workflowsummaryData, 
            _id: data[0],
            workflow_name: data[1],
            start_time: data[2],
            average_runtime: data[3],
            run_frequency: data[4],
            job_dependency: data[5],
            source_type: data[6],
            source_connection: data[7],
            intermediate_table: data[8],
            ingestion_method: data[9],
            target: data[10]
        })
        setOpen(true)
    }
    const delWorkflowsummary =(value) =>{
        var data = value.rowData;
        setWorkflowsummaryData({...workflowsummaryData, 
            _id: data[0],
            workflow_name: data[1],
            start_time: data[2],
            average_runtime: data[3],
            run_frequency: data[4],
            job_dependency: data[5],
            source_type: data[6],
            source_connection: data[7],
            intermediate_table: data[8],
            ingestion_method: data[9],
            target: data[10]
        })
        setDialogOpen(true);
    }
    const workflowsummaryColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 'workflow_name',
            label: 'Workflow Name',
            align: 'center',
        },
        { 
            name: 'start_time',
            label: 'Start Time',
            align: 'center'
        },
        { 
            name: 'average_runtime',
            label: 'Average Runtime',
            align: 'center'
        },
        { 
            name: 'run_frequency',
            label: 'Run Frequency',
            align: 'center'
        },
        {
            name: 'job_dependency',
            label: 'Job Dependency',
            align: 'center'
        },
        { 
            name: 'source_type',
            label: 'Source Type',
            align: 'center'
        },
        {
            name: 'source_connection',
            label: 'Source Connection',
            align: 'center'
        }, 
        {
            name: 'intermediate_table',
            label: 'Intermediate Table',
            align: 'center'
        }, 
        {
            name: 'ingestion_method',
            label: 'Ingestion Method',
            align: 'center'
        },
        { 
            name: 'target',
            label: 'Target',
            align: 'center'
        },
        {
            name: 'action',
            label: 'ACTION',
            align: 'center',
            options: {
                customBodyRender: (value, tableMeta, updateValue)  => {
                    return (
                        <Box sx={{display:'flex', justifyContent:'left'}}>
                            <IconButton onClick = {()=>{editWorkflowsummaryData(tableMeta); setOpen(true)}} color="primary"><BorderColorSharpIcon/></IconButton>
                            <IconButton onClick = {()=>{delWorkflowsummary(tableMeta)}} color="primary"><DeleteIcon/></IconButton>
                        </Box>
                    );
                },
                filter: false
            },
           
            
        },
    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,
        customToolbar: () => {
            return (
                <ColorButton onClick={()=>{setWorkflowsummaryData(workflowsummaryStructure); setOpen(true)}}>
                    Add Rule
                </ColorButton>
            );
        },
      };
    return(
        <Container maxWidth="xxl" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={workflowsummaryList}
                        columns={workflowsummaryColumn}
                        options={options}
                        title={"Workflow Summary"}
                    />
                </ThemeProvider>
            </Box>
            <WorkflowsummaryDialog open={open} setOpen={setOpen} data = {workflowsummaryData}/>
            <Dialog
                open={dialogOpen}
                TransitionComponent={Transition}
                keepMounted
                onClose={()=> {setDialogOpen(false)}}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>Confirm Dialog</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-slide-description">
                        Do you want to delete it? Once you delete it, you can't recovery again
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button  sx={{background: "#F64E60", color: "#ffff", marginRight:"20px",'&:hover': { background: "#F64E60",}}} onClick={()=>{dispatch(delWorkflowsummary(workflowsummaryData._id)); setDialogOpen(false)}}>Agree</Button>
                    <Button onClick={()=>{setDialogOpen(false)}}>Disagree</Button>
                    
                </DialogActions>
            </Dialog>
        </Container>
    );
}
export default Content;