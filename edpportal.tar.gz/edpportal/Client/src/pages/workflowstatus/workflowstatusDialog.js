import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { toast, ToastContainer } from "react-toastify";


import {useDispatch } from 'react-redux';
import {
  addWorkflowstatus
} from '../../actions/workflowstatusAction';

export default function WorkflowstatusDialog(props) {

  const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.workflow_name === ""){
      toast.error("Workflow Name Required!");
    }else if(formData.start_time === ""){
      toast.error("Start Time Required!");
    }else if(formData.average_runtime === ""){
      toast.error("Average Time Required!");
    }else if(formData.frequency === ""){
      toast.error("Frequency Required!");
    }else if(formData.duration === ""){
      toast.error("Duration Required!");
    }else if(formData.status === ""){
      toast.error("Status Required!");
    }else if(formData.sla === ""){
      toast.error("SLA Required!");
    }else{
      dispatch(addWorkflowstatus(formData));
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>Workflow Status</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Workflow Status
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="workflow_name"
            label="Workflow Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.workflow_name}
            onChange={evt => { setFormData(f => ({ ...f, workflow_name: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="start_time"
            label="Start Time"
            type="text"
            fullWidth
            variant="standard"
            value={formData.start_time}
            onChange={evt => { setFormData(f => ({ ...f, start_time: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="average_runtime"
            label="Average Time"
            type="text"
            fullWidth
            variant="standard"
            value={formData.average_runtime}
            onChange={evt => { setFormData(f => ({ ...f, average_runtime: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="frequency"
            label="Frequency"
            type="text"
            fullWidth
            variant="standard"
            value={formData.frequency}
            onChange={evt => { setFormData(f => ({ ...f, frequency: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="duration"
            label="Duration"
            type="text"
            fullWidth
            variant="standard"
            value={formData.duration}
            onChange={evt => { setFormData(f => ({ ...f, duration: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="workflow_status"
            label="workflow Status"
            type="text"
            fullWidth
            variant="standard"
            value={formData.workflow_status}
            onChange={evt => { setFormData(f => ({ ...f, workflow_status: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="sla"
            label="SLA"
            type="text"
            fullWidth
            variant="standard"
            value={formData.sla}
            onChange={evt => { setFormData(f => ({ ...f, sla: evt.target.value})) }}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}