import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import { 
    Box, 
    IconButton,
    Button,
    Dialog,
    DialogContent,
    DialogActions,
    DialogContentText,
    DialogTitle,
    Slide 
} from '@mui/material';

import DeleteIcon from '@mui/icons-material/Delete';
import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import WorkflowstatusDialog from './workflowstatusDialog';

import { workflowstatusStructure } from '../../config/const';

import {getAll, delWorkflowstatus, selectWorkflowstatus} from '../../actions/workflowstatusAction';

const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const ColorButton = styled(Button)(({ theme }) => ({
    backgroundColor: '#E1F0FF',
    fontSize: '11px',
    paddingLeft: '10px',
    paddingRight: '10px',
    marginLeft: '15px',
    color:'#3699FF',
    '&:hover': {
        color: '#FFFFFF',
        backgroundColor: '#3699FF',
    },
    boxShadow: 'none'
}));

const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
            borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
            '&:not(:last-child)': {
                borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
            alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
            background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    useEffect(()=>{
        dispatch(getAll());
    }, [])
    const workflowstatusList = useSelector(selectWorkflowstatus);
    const [open, setOpen] = useState(false);
    const [workflowstatusData, setWorkflowstatusData] = useState(workflowstatusStructure);
    const [dialogOpen, setDialogOpen] = useState(false);
    const editWorkflowstatusData=(value)=>{
        var data = value.rowData;
        setWorkflowstatusData({...workflowstatusData, 
            _id: data[0],
            workflow_name: data[1],
            start_time: data[2],
            average_runtime: data[3],
            frequency: data[4],
            duration: data[5],
            workflow_status: data[6],
            sla: data[7]
        })
        setOpen(true)
    }
    const delWorkflowstatus =(value) =>{
        var data = value.rowData;
        setWorkflowstatusData({...workflowstatusData, 
            _id: data[0],
            workflow_name: data[1],
            start_time: data[2],
            average_runtime: data[3],
            frequency: data[4],
            duration: data[5],
            workflow_status: data[6],
            sla: data[7]
        })
        setDialogOpen(true);
    }
    const workflowstatusColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        },
        { 
            name: 'workflow_name',
            label: 'Workflow Name',
            align: 'center',
        },
        { 
            name: 'start_time',
            label: 'Start Time',
            align: 'center'
        },
        { 
            name: 'average_runtime',
            label: 'Average Runtime',
            align: 'center'
        },
        { 
            name: 'frequency',
            label: 'Frequency',
            align: 'center'
        },
        {
            name: 'duration',
            label: 'Duration',
            align: 'center'
        },
        { 
            name: 'workflow_status',
            label: 'Workflow status',
            align: 'center'
        },
        {
            name: 'sla',
            label: 'SLA',
            align: 'center'
        }, 
        {
            name: 'action',
            label: 'ACTION',
            align: 'center',
            options: {
                customBodyRender: (value, tableMeta, updateValue)  => {
                    return (
                        <Box sx={{display:'flex', justifyContent:'left'}}>
                            <IconButton onClick = {()=>{editWorkflowstatusData(tableMeta); setOpen(true)}} color="primary"><BorderColorSharpIcon/></IconButton>
                            <IconButton onClick = {()=>{delWorkflowstatus(tableMeta)}} color="primary"><DeleteIcon/></IconButton>
                        </Box>
                    );
                },
                filter: false
            },
           
            
        },
    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,
        customToolbar: () => {
            return (
                <ColorButton onClick={()=>{setWorkflowstatusData(workflowstatusStructure); setOpen(true)}}>
                    Add Rule
                </ColorButton>
            );
        },
      };
    return(
        <Container maxWidth="xxl" sx={{padding: "0px !important"}}>
            <Box sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={workflowstatusList}
                        columns={workflowstatusColumn}
                        options={options}
                        title={"Workflow status"}
                    />
                </ThemeProvider>
            </Box>
            <WorkflowstatusDialog open={open} setOpen={setOpen} data = {workflowstatusData}/>
            <Dialog
                open={dialogOpen}
                TransitionComponent={Transition}
                keepMounted
                onClose={()=> {setDialogOpen(false)}}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>Confirm Dialog</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-slide-description">
                        Do you want to delete it? Once you delete it, you can't recovery again
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button  sx={{background: "#F64E60", color: "#ffff", marginRight:"20px",'&:hover': { background: "#F64E60",}}} onClick={()=>{dispatch(delWorkflowstatus(workflowstatusData._id)); setDialogOpen(false)}}>Agree</Button>
                    <Button onClick={()=>{setDialogOpen(false)}}>Disagree</Button>
                    
                </DialogActions>
            </Dialog>
        </Container>
    );
}
export default Content;