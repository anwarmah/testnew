import React from 'react';
import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import Container from '@mui/material/Container';
import MUIDataTable from 'mui-datatables';
import { ThemeProvider } from '@mui/styles';
import { createTheme } from '@mui/material/styles';
import { styled } from '@mui/material/styles';
import MetricChart from './metricChart';
import MetricChartPercentage from './metricChartpercentage'
import DqiChart from './dqiChart';
import DqiChartPercentage from './dqiChartpercentage';
import DQIMetricAccuracyChart from './accuracymetricChartper';
import DQIMetricCompletenessChart from './completenessmetricChartper';
import DQIMetricConsistencyChart from './consistencymetricChartper';
import DQIMetricIntegrityChart from './integritymetricChartper';
import DQIMetricTimelinenessChart from './timelinenessmetricChartper';
import { 
    Box, 
    IconButton,
    Button,
    Dialog,
    DialogContent,
    DialogActions,
    DialogContentText,
    DialogTitle,
    Slide,
    Grid 
} from '@mui/material';

import DeleteIcon from '@mui/icons-material/Delete';
import BorderColorSharpIcon from '@mui/icons-material/BorderColorSharp';

import DqmetricDialog from './dqmetricDialog';

import { dqmetricStructure } from '../../config/const';

import {getAll, delDqmetric, selectDqmetric} from '../../actions/dqmetricAction';
// import DQIMetricConsistencyChart from './consistencymetricChartper';


const Transition = React.forwardRef(function Transition(props, ref) {
    return <Slide direction="up" ref={ref} {...props} />;
});

const ColorButton = styled(Button)(({ theme }) => ({
    backgroundColor: '#E1F0FF',
    fontSize: '11px',
    paddingLeft: '10px',
    paddingRight: '10px',
    marginLeft: '15px',
    color:'#3699FF',
    '&:hover': {
        color: '#FFFFFF',
        backgroundColor: '#3699FF',
    },
    boxShadow: 'none'
}));

const theme = createTheme({
    Overrides: {
        MUIDataTable: {
            root: {
                border: [[1, 'solid', 'red']],
            },
            paddingLeft: '15px !important'
        },
        MuiTableCell: {
            root: {
            borderColor: '#d3d3d3',
            },
            head: {
            background: 'lightgrey',
            '&:not(:last-child)': {
                borderRight: [[1, 'solid', '#c0c0c0']],
            },
            },
        },
        MuiTableSortLabel: {
            root: {
            alignItems: 'flex-start',
            },
        },
        MuiTableFooter: {
            root: {
            background: 'lightgrey',
            },
        },
    
        // MUIDataTable
        MUIDataTableHeadCell: {
            sortLabelRoot: {
            // height: undefined,
            },
        },
        },
});

const Content = () =>{
    const dispatch = useDispatch();
    const [filter, setFilter] = useState({date:'', type:''});
    useEffect(()=>{
        dispatch(getAll(filter));
    }, [filter])
    const dqmetricList = useSelector(selectDqmetric);
    const [open, setOpen] = useState(false);
  
    const [dqmetricData, setDqmetricData] = useState(dqmetricStructure);
    const [dialogOpen, setDialogOpen] = useState(false);
    const editDqmetricData=(value)=>{
        var data = value.rowData;
        setDqmetricData({...dqmetricData, 
            _id: data[0],
            // check_type: data[1],
            // rule_cd: data[2],
            // product_nm: data[3],
            // database_nm: data[4],
            // table_nm: data[5],
            // field_nm: data[6],
            // system_nm: data[7],
            // job_name: data[8],
            // dq_type_nm: data[9],
            // domain_owner: data[10],
            // alert_owner: data[11],
            // trns_dt_key: data[12],
            // aggr_key: data[13],
            // calc_type: data[14],
            // metric_1_value: data[15],
            // metric_2_value: data[16],
            // calc_value: data[17],
            // thrshld_cd: data[18],
            // inserted_ts: data[19],
            // inserted_by: data[20]
            check_type: data[1],
            rule_cd: data[2],
            table_nm: data[3],
            field_nm: data[4],
            job_name: data[5],
            dq_type_nm: data[6],
            dqi_indicator: data[7],
            dq_check_description: data[8],
            dq_type_nm: data[9],
            trns_dt_key: data[10],
            aggr_key: data[11],
            calc_type: data[12],
            metric_1_value: data[13],
            calc_value: data[14],
            thrshld_cd: data[15],
            inserted_ts: data[16]
        })
        setOpen(true)
    }
    const deleteDqmetric =(value) =>{
        var data = value.rowData;
        setDqmetricData({...dqmetricData, 
            _id: data[0],
            // check_type: data[1],
            // rule_cd: data[2],
            // product_nm: data[3],
            // database_nm: data[4],
            // table_nm: data[5],
            // field_nm: data[6],
            // system_nm: data[7],
            // job_name: data[8],
            // dq_type_nm: data[9],
            // domain_owner: data[10],
            // alert_owner: data[11],
            // trns_dt_key: data[12],
            // aggr_key: data[13],
            // calc_type: data[14],
            // metric_1_value: data[15],
            // metric_2_value: data[16],
            // calc_value: data[17],
            // thrshld_cd: data[18],
            // inserted_ts: data[19],
            // inserted_by: data[20]
            check_type: data[1],
            rule_cd: data[2],
            table_nm: data[3],
            field_nm: data[4],
            job_name: data[5],
            dq_type_nm: data[6],
            dqi_indicator: data[7],
            dq_check_description: data[8],
            dq_type_nm: data[9],
            trns_dt_key: data[10],
            aggr_key: data[11],
            calc_type: data[12],
            metric_1_value: data[13],
            calc_value: data[14],
            thrshld_cd: data[15],
            inserted_ts: data[16]
        })
        setDialogOpen(true);
    }
    const dqmetricColumn = [
        { 
            name: '_id',
            options: {
                filter: false,
                display: false,
                viewColumns: false,
                sort: false
            }
        }, 
            { 
                name: 'check_type',
                label: 'DQ Check Type',
                align: 'center',
            },
            { 
                name: 'rule_cd',
                label: 'Rule Code',
                align: 'center'
            },
            // {
            //     name: 'product_nm',
            //     label: 'Product Name',
            //     align: 'center'
            // },
            // {
            //     name: 'database_nm',
            //     label: 'Database Name',
            //     align: 'center'
            // },
            { 
                name: 'table_nm',
                label: 'Table Name',
                align: 'center'
            },
            { 
                name: 'field_nm',
                label: 'Column Name',
                align: 'center'
            },
            // {
            //     name: 'system_nm',
            //     label: 'System Name',
            //     align: 'center'
            // },
            {
                name: 'job_name',
                label: 'Job Name',
                align: 'center'
            },
            { 
                name: 'dq_type_nm',
                label: 'DQ Category',
                align: 'center'
            },
            {
                name: 'dqi_indicator',
                label: 'DQI Indicator',
                align: 'center'
            }, 
            {
                name: 'dq_check_description',
                label: 'DQ Check Description',
                align: 'center'
            }, 
            // { 
            //     name: 'domain_owner',
            //     label: 'Domain Owner',
            //     align: 'center'
            // },x`
            // {
            //     name: 'alert_owner',
            //     label: 'Alert Owner',
            //     align: 'center'
            // },
            {
                name: 'trns_dt_key',
                label: 'Transaction Date',
                align: 'center'
            },
            { 
                name: 'aggr_key',
                label: 'DQ Run Date',
                align: 'center'
            },
            {
                name: 'calc_type',
                label: 'DQ Measurement Type',
                align: 'center'
            },
            {
                name: 'metric_1_value',
                label: 'Expected value',
                align: 'center'
            },
            // { 
            //     name: 'metric_2_value',
            //     label: 'Metric 2 Value',
            //     align: 'center'
            // },
            { 
                name: 'calc_value',
                label: 'Actual Value',
                align: 'center'
            },
            {
                name: 'thrshld_cd',
                label: 'Result',
                align: 'center'
            },
            {
                name: 'inserted_ts',
                label: 'Inserted TS',
                align: 'center'
            }, 
            // {
            //     name: 'inserted_by',
            //     label: 'Inserted By',
            //     align: 'center'
            // }, 
           {
            name: 'action',
            label: 'ACTION',
            align: 'center',
            options: {
                customBodyRender: (value, tableMeta, updateValue)  => {
                    return (
                        <Box sx={{display:'flex', justifyContent:'left'}}>
                            <IconButton onClick = {()=>{editDqmetricData(tableMeta); setOpen(true)}} color="primary"><BorderColorSharpIcon/></IconButton>
                            <IconButton onClick = {()=>{deleteDqmetric(tableMeta)}} color="primary"><DeleteIcon/></IconButton>
                        </Box>
                    );
                },
                filter: false
            },
           
            
        },
    ];
    const options = {
        // responsive: '',
        fixedHeader: false,
        filterType: 'textField',
        selectableRows: 'none',
        elevation: 0,
        print: false,
        download:false,
        customToolbar: () => {
            return (
                <ColorButton onClick={()=>{setDqmetricData(dqmetricStructure); setOpen(true)}}>
                    Add Rule
                </ColorButton>
            );
        },
      };
    return(
        <Container maxWidth="xxl" sx={{ marginTop:'30px',marginBottom:'30px',marginRight:'10px'}}>
        {/* <Container maxWidth="xxl"  sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}> */}
            <Box>
                <Grid container spacing={12} >
                  <Grid item xs={12} lg={5.9} sx={{marginRight:'5px',marginLeft:'10px'}}>
                    <MetricChart setFilter = {setFilter}/>
                  </Grid>
                  <Grid item xs={12} lg={5.9}>
                  <MetricChartPercentage />
                  </Grid>
                </Grid>
                {/* <Grid container spacing={12}>
                  <Grid DqiChartPercentage xs={12} lg={12}>
                    <DqiChartPercentage />
                  </Grid>
                </Grid> */}
            </Box>
            <Box sx={{ marginTop:'30px'}}>
                <Grid container spacing={12} >
                  <Grid item xs={12} lg={5.9} sx={{marginRight:'5px',marginLeft:'10px'}}>
                    <DqiChartPercentage />
                  </Grid>
                  <Grid item xs={12} lg={5.9}>
                  <DQIMetricTimelinenessChart />
                  </Grid>
                </Grid>
            </Box>
            <Box sx={{ marginTop:'30px'}}>
                <Grid container spacing={12} >
                  <Grid item xs={12} lg={5.9} sx={{marginRight:'5px',marginLeft:'10px'}}>
                    <DQIMetricAccuracyChart />
                  </Grid>
                  <Grid item xs={12} lg={5.9}>
                  <DQIMetricCompletenessChart />
                  </Grid>
                </Grid>
            </Box>
            <Box sx={{ marginTop:'30px'}}>
                <Grid container spacing={12} >
                  <Grid item xs={12} lg={5.9} sx={{marginRight:'5px',marginLeft:'10px'}}>
                    <DQIMetricConsistencyChart />
                  </Grid>
                  <Grid item xs={12} lg={5.9}>
                  <DQIMetricIntegrityChart />
                  </Grid>
                </Grid>
            </Box>
            {/* <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <MetricChart setFilter = {setFilter}/>
            </Box>
            <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'-581px',marginBottom:'30px', marginLeft:'770px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <MetricChartPercentage setFilter = {setFilter}/>
            </Box>   */}

            {/* <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DqiChart setFilter = {setFilter}/>
            </Box>  */}

            {/* <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DqiChartPercentage setFilter = {setFilter}/>
            </Box> 
            <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'-581px',marginBottom:'30px', marginLeft:'770px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricTimelinenessChart setFilter = {setFilter}/>
            </Box> 
            <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricAccuracyChart setFilter = {setFilter}/>
            </Box> 
            <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'-581px',marginBottom:'30px', marginLeft:'770px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricCompletenessChart setFilter = {setFilter}/>
            </Box>  */}

            {/* <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginBottom:'30px', marginLeft:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricCompletenessChart setFilter = {setFilter}/>
            </Box>     */}

            {/* <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricConsistencyChart setFilter = {setFilter}/>
            </Box> 
            <Box maxWidth="md" sx={{ bgcolor: '#fff', height: '50%',width:'50%', marginTop:'-581px',marginBottom:'30px', marginLeft:'770px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <DQIMetricIntegrityChart setFilter = {setFilter}/>
            </Box>                      */}
            <Box maxWidth="xxl" sx={{ bgcolor: '#fff', height: '100%',width:'100%', marginTop:'30px',marginBottom:'30px', boxShadow:'0px 0px 30px 0px rgb(82 63 105 / 5%)'}}>
                <ThemeProvider theme={theme}>
                    <MUIDataTable sx={{bgcolor: '#fff'}}
                        data={dqmetricList}
                        columns={dqmetricColumn}
                        options={options}
                        title={"DQ Metrics"}
                    />
                </ThemeProvider>
            </Box> 
            <DqmetricDialog open={open} setOpen={setOpen} data = {dqmetricData}/>
            <Dialog
                open={dialogOpen}
                TransitionComponent={Transition}
                keepMounted
                onClose={()=> {setDialogOpen(false)}}
                aria-describedby="alert-dialog-slide-description"
            >
                <DialogTitle>Confirm Dialog</DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-slide-description">
                        Do you want to delete it? Once you delete it, you can't recovery again
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button  sx={{background: "#F64E60", color: "#ffff", marginRight:"20px",'&:hover': { background: "#F64E60",}}} onClick={()=>{dispatch(delDqmetric(dqmetricData._id)); setDialogOpen(false)}}>Agree</Button>
                    <Button onClick={()=>{setDialogOpen(false)}}>Disagree</Button>
                    
                </DialogActions>
            </Dialog>
        </Container>
    );
}
export default Content;