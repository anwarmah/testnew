import React, {useState, useEffect} from "react";
// import { Bar} from "react-chartjs-2";
import { Line} from "react-chartjs-2";
import {
    Card,
    CardHeader,
    Avatar,
    Typography,
    CardContent,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Slider,
    Box
} from '@mui/material';
import {red,} from '@mui/material/colors';
import { ArcElement} from 'chart.js';
import Chart from 'chart.js/auto'
// import BarChartIcon from '@mui/icons-material/BarChart';
import LineChartIcon from '@mui/icons-material/StackedLineChart';
import { useSelector, useDispatch } from 'react-redux';
import { getChartData, selectChartData, getDqiChartCountData, selectDqiChartCountData } from "../../actions/dqmetricAction";
import { months } from '../../config/const';
Chart.register(ArcElement);
function valuetext(value) {
  return `$${value}`;
}
var origindata = {
  labels: ["Missing Data. Please check server..."],
  datasets: [
    {
      data: [],
      label: 'ACCURACY_FAIL',
      backgroundColor: '#EC932F',
      borderColor: '#EC932F',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#EC932F',
    },
    {
      data: [],
      label: 'ACCURACY_PASS',
      backgroundColor: '#3498db',
      borderColor: '#3498db',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#3498db',
    }
  ]
};
const DQIMetricCountChart = (props) =>{
    const [range, setRange] = React.useState([1, 31]);
    const [max, setMax] = useState(31);
    const dispatch = useDispatch();
    const [year, setYear] =useState(new Date().getFullYear());
    const [month, setMonth] =useState(new Date().getMonth()+1);
    var years = [];
    for(var i = year-10; i < year+10 ; i++){
      years.push(i);
    }

    const[dqichartcountdata, setChartCountData] = useState(origindata);

    useEffect(() => {
      dispatch(getDqiChartCountData({year:year, month:month, range:range}));
    },[year, month]);

    const columnData = useSelector(selectDqiChartCountData);
    const changeFilter = (event, newValue) => {
      var from = new Date(year+"-"+month+"-"+newValue[0]).getTime();
      var to = new Date(year+"-"+month+"-"+newValue[1]).getTime();
      
      var label=[];
      var accuracypass=[];
      var accuracyfail = [];
      for (var i = 0; i < columnData.length; i++){
        if(from <= new Date(columnData[i]._id).getTime() && new Date(columnData[i]._id).getTime()<= to){
          label.push(columnData[i]._id);
          var total=columnData[i].accuracy_pass_count+columnData[i].accuracy_fail_count
          var accuracy_pass_count=((columnData[i].accuracy_pass_count/total)*100).toFixed(2);
          var accuracy_fail_count=((columnData[i].accuracy_fail_count/total)*100).toFixed(2);
          accuracypass.push(accuracy_pass_count);
          accuracyfail.push(accuracy_fail_count);
          // pass.push(columnData[i].pass_count);
          // fail.push(columnData[i].failed_count);
        }
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: accuracypass,
            label: 'ACCURACY_PASS',
            backgroundColor: '#3498db',
            borderColor: '#3498db',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#3498db',
          },
          {
            data: accuracyfail,
            label: 'ACCURACY_FAIL',
            backgroundColor: '#EC932F',
            borderColor: '#EC932F',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#EC932F',
          }
        ]
      };
      setChartCountData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = accuracypass;
      origindata.datasets[1].data = accuracyfail;
      setRange(newValue);
    };
    useEffect(() => {
      var label=[];
      var accuracypass=[];
      var accuracyfail = [];
      for (var i = 0; i < columnData.length; i++){
        label.push(columnData[i]._id);
        var total=columnData[i].accuracy_pass_count+columnData[i].accuracy_fail_count
        var accuracy_pass_count=((columnData[i].accuracy_pass_count/total)*100).toFixed(2);
        var accuracy_fail_count=((columnData[i].accuracy_fail_count/total)*100).toFixed(2);
        accuracypass.push(accuracy_pass_count);
        accuracyfail.push(accuracy_fail_count);
        // pass.push(columnData[i].pass_count);
        // fail.push(columnData[i].failed_count);
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: accuracypass,
            label: 'ACCURACY_PASS',
            backgroundColor: '#3498db',
            borderColor: '#3498db',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#3498db',
          },
          {
            data: accuracyfail,
            label: 'ACCURACY_FAIL',
            backgroundColor: '#EC932F',
            borderColor: '#EC932F',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#EC932F',
          }
        ]
      };
      setChartCountData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = accuracypass;
      origindata.datasets[1].data = accuracyfail;
    }, [columnData]);
    return (
        <Card sx={{boxShadow:'0px 0px 30px 10px rgb(82 63 105 / 15%)'}}>
          <CardHeader
            avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
                {/* <BarChartIcon/> */}
                <LineChartIcon/>
            </Avatar>
            }
            title={<Typography variant='h5'>Accuracy Percentage Chart</Typography>}
            action={
              <Box sx={{width: "200px"}}>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Year</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={year}
                    onChange={evt => { setYear(evt.target.value); setMax(new Date(evt.target.value, month, 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {years.map((item)=>{
                      return <MenuItem key={item} value={item}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Month</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={month}
                    onChange={evt => { setMonth(evt.target.value); setMax(new Date(year,evt.target.value , 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {months.map((item, index)=>{
                      return <MenuItem key={index} value={index+1}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Box>
            }
          />
          <CardContent>
            <Grid 
              container 
              spacing={1} 
              direction={"column"} 
              justifyContent={'flex-start'} 
              alignItems={'center'}>
              <Grid item lg={3} style={{width:'inherit'}}>
                {/* <Bar */}
                <Line  
                  data={dqichartcountdata}
                  options={{
                    onClick: function(evt, element) {
                      if(element.length > 0) {
                        var filter = {}
                        if(element[0].datasetIndex == 1){
                          filter["type"]="ACCURACY_FAIL";
                        }else{
                        filter["type"]="ACCURACY_PASS";
                        }
                        filter["date"] = dqichartcountdata.labels[element[0].index];
                        props.setFilter(filter);
                      }
                    },
                    plugins: {
                      tooltip: {
                        // Disable the on-canvas tooltip
                        enabled: false,
        
                        external: function(context) {
                            // Tooltip Element
                            let tooltipEl = document.getElementById('chartjs-tooltip');
        
                            // Create element on first render
                            if (!tooltipEl) {
                                tooltipEl = document.createElement('div');
                                tooltipEl.id = 'chartjs-tooltip';
                                tooltipEl.innerHTML = '<table></table>';
                                document.body.appendChild(tooltipEl);
                            }
        
                            // Hide if no tooltip
                            const tooltipModel = context.tooltip;
                            if (tooltipModel.opacity === 0) {
                                tooltipEl.style.opacity = 0;
                                return;
                            }
        
                            // Set caret Position
                            tooltipEl.classList.remove('above', 'below', 'no-transform');
                            if (tooltipModel.yAlign) {
                                tooltipEl.classList.add(tooltipModel.yAlign);
                            } else {
                                tooltipEl.classList.add('no-transform');
                            }
        
                            var accuracypass = dqichartcountdata.datasets[0].data[tooltipModel.dataPoints[0].dataIndex];
                            var accuracyfail = dqichartcountdata.datasets[1].data[tooltipModel.dataPoints[0].dataIndex];
                            // Set Text
                            if (tooltipModel.body) {
                                const titleLines = tooltipModel.title || [];
        
                                let innerHtml = '<thead>';
        
                                titleLines.forEach(function(title) {
                                    innerHtml += '<tr><th>' + title + '</th></tr>';
                                });
                                innerHtml += '</thead><tbody>';
                                
                                let accuracypassStyle = 'background:' + dqichartcountdata.datasets[0].backgroundColor;
                                accuracypassStyle += '; border-color:' + dqichartcountdata.datasets[0].borderColor;
                                accuracypassStyle += '; border-width: 2px';
                                accuracypassStyle += '; width: 12px; height:12px; display: inline-block; margin-right:5px;';
                                let accuracypassSpan = '<span style="' + accuracypassStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + accuracypassSpan +'ACCURACY_PASS: '+ accuracypass + '</td></tr>';

                                let accuracyfailStyle = 'background:' + dqichartcountdata.datasets[1].backgroundColor;
                                accuracyfailStyle += '; border-color:' + dqichartcountdata.datasets[1].borderColor;
                                accuracyfailStyle += '; border-width: 2px';
                                accuracyfailStyle += '; border-width: 2px';
                                accuracyfailStyle += '; width: 12px; height:12px; display: inline-block;  margin-right:5px;';
                                let accuracyfailSpan = '<span style="' + accuracyfailStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + accuracyfailSpan +'ACCURACY_FAIL: '+ accuracyfail + '</td></tr>';

                                innerHtml += '</tbody>';
        
                                let tableRoot = tooltipEl.querySelector('table');
                                tableRoot.innerHTML = innerHtml;
                            }
        
                            const position = context.chart.canvas.getBoundingClientRect();
                            // const bodyFont = Chart.helpers.toFont(tooltipModel.options.bodyFont);
        
                            // Display, position, and set styles for font
                            tooltipEl.style.opacity = 1;
                            tooltipEl.style.position = 'absolute';
                            tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
                            tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
                            // tooltipEl.style.font = bodyFont.string;
                            tooltipEl.style.padding = tooltipModel.padding + 'px ' + tooltipModel.padding + 'px';
                            tooltipEl.style.pointerEvents = 'none';
                        }
                      }
                    }
                  }}
                />
              </Grid>
              <Box style={{width:'inherit'}} sx={{ width: 600, paddingLeft:'20px', paddingRight:'20px', paddingTop:'20px'}}>
                  <Slider
                      getAriaLabel={() => 'Date Range'}
                      value={range}
                      onChange={changeFilter}
                      valueLabelDisplay="auto"
                      max={max}
                      getAriaValueText={valuetext}
                  />
              </Box>
            </Grid>
          </CardContent>
        </Card>
    );
  }

export default DQIMetricCountChart;