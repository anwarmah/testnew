import React, {useState, useEffect} from "react";
// import { Bar} from "react-chartjs-2";
import { Line} from "react-chartjs-2";
import {
    Card,
    CardHeader,
    Avatar,
    Typography,
    CardContent,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Slider,
    Box
} from '@mui/material';
import {red,} from '@mui/material/colors';
import { ArcElement} from 'chart.js';
import Chart from 'chart.js/auto'
// import BarChartIcon from '@mui/icons-material/BarChart';
import LineChartIcon from '@mui/icons-material/StackedLineChart';
import { useSelector, useDispatch } from 'react-redux';
import { getDqiChartData, selectDqiChartData } from "../../actions/dqmetricAction";
import { months } from '../../config/const';
Chart.register(ArcElement);
function valuetext(value) {
  return `$${value}`;
}
var origindata = {
  labels: ["Missing Data. Please check server..."],
  datasets: [
    {
      data: [],
      label: 'ACCURACY',
      backgroundColor: '#EC932F',
      borderColor: '#EC932F',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#EC932F',
    },
    {
      data: [],
      label: 'COMPLETENESS',
      backgroundColor: '#3498db',
      borderColor: '#3498db',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#3498db',
    },
    {
      data: [],
      label: 'CONSISTENCY',
      backgroundColor: '#00FFFF',
      borderColor: '#00FFFF',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#00FFFF',
    },
    {
      data: [],
      label: 'INTEGRITY',
      backgroundColor: '#7FFF00',
      borderColor: '#7FFF00',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#7FFF00',
    },
    {
      data: [],
      label: 'TIMELINENESS',
      backgroundColor: '#a52a2a',
      borderColor: '#a52a2a',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: '#a52a2a',
    }
  ]
};
const DqiChart = (props) =>{
    const [range, setRange] = React.useState([1, 31]);
    const [max, setMax] = useState(31);
    const dispatch = useDispatch();
    const [year, setYear] =useState(new Date().getFullYear());
    const [month, setMonth] =useState(new Date().getMonth()+1);
    var years = [];
    for(var i = year-10; i < year+10 ; i++){
      years.push(i);
    }

    const[dqichartdata, setDqiChartData] = useState(origindata);

    useEffect(() => {
      dispatch(getDqiChartData({year:year, month:month, range:range}));
    },[year, month]);

    const columnData = useSelector(selectDqiChartData);
    console.log({columnData});
    const changeFilter = (event, newValue) => {
      var from = new Date(year+"-"+month+"-"+newValue[0]).getTime();
      var to = new Date(year+"-"+month+"-"+newValue[1]).getTime();
      
      var label=[];
      var accuracy=[];
      var completeness = [];
      var consistency=[];
      var integrity = [];
      var timelineness = [];
      for (var i = 0; i < columnData.length; i++){
        if(from <= new Date(columnData[i]._id).getTime() && new Date(columnData[i]._id).getTime()<= to){
          label.push(columnData[i]._id);
        //   var total=columnData[i].accuracy_count+columnData[i].timelineness_count
          var total=columnData[i].accuracy_count+columnData[i].completeness_count+columnData[i].consistency_count+columnData[i].integrity_count+columnData[i].timelineness_count
          var accuracy_count=((columnData[i].accuracy_count/total)*100).toFixed(2);
          var completeness_count=((columnData[i].completeness_count/total)*100).toFixed(2);
          var consistency_count=((columnData[i].consistency_count/total)*100).toFixed(2);
          var integrity_count=((columnData[i].integrity_count/total)*100).toFixed(2);
          var timelineness_count=((columnData[i].timelineness_count/total)*100).toFixed(2);
          accuracy.push(accuracy_count);
          completeness.push(completeness_count);
          consistency.push(consistency_count);
          integrity.push(integrity_count);
          timelineness.push(timelineness_count);
          // pass.push(columnData[i].pass_count);
          // fail.push(columnData[i].failed_count);
        }
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: accuracy,
            label: 'ACCURACY',
            backgroundColor: '#EC932F',
            borderColor: '#EC932F',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#EC932F',
          },
          {
            data: completeness,
            label: 'COMPLETENESS',
            backgroundColor: '#3498db',
            borderColor: '#3498db',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#3498db',
          },
          {
            data: consistency,
            label: 'CONSISTENCY',
            backgroundColor: '#00FFFF',
            borderColor: '#00FFFF',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#00FFFF',
          },
          {
            data: integrity,
            label: 'INTEGRITY',
            backgroundColor: '#7FFF00',
            borderColor: '#7FFF00',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#7FFF00',
          },
          {
            data: timelineness,
            label: 'TIMELINENESS',
            backgroundColor: '#a52a2a',
            borderColor: '#a52a2a',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#a52a2a',
          }
        ]
      };
      setDqiChartData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = accuracy;
      origindata.datasets[1].data = completeness;
      origindata.datasets[2].data = consistency;
      origindata.datasets[3].data = integrity;
      origindata.datasets[4].data = timelineness;
      setRange(newValue);
    };
    useEffect(() => {
      var label=[];
      var accuracy=[];
      var completeness = [];
      var consistency=[];
      var integrity = [];
      var timelineness = [];
      for (var i = 0; i < columnData.length; i++){
        label.push(columnData[i]._id);
        // var total=columnData[i].accuracy_count+columnData[i].timelineness_count
        var total=columnData[i].accuracy_count+columnData[i].completeness_count+columnData[i].consistency_count+columnData[i].integrity_count+columnData[i].timelineness_count
        var accuracy_count=((columnData[i].accuracy_count/total)*100).toFixed(2);
        var completeness_count=((columnData[i].completeness_count/total)*100).toFixed(2);
        var consistency_count=((columnData[i].consistency_count/total)*100).toFixed(2);
        var integrity_count=((columnData[i].integrity_count/total)*100).toFixed(2);
        var timelineness_count=((columnData[i].timelineness_count/total)*100).toFixed(2);
        accuracy.push(accuracy_count);
        completeness.push(completeness_count);
        consistency.push(consistency_count);
        integrity.push(integrity_count);
        timelineness.push(timelineness_count);
        // pass.push(columnData[i].pass_count);
        // fail.push(columnData[i].failed_count);
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: accuracy,
            label: 'ACCURACY',
            backgroundColor: '#EC932F',
            borderColor: '#EC932F',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#EC932F',
          },
         {
            data: completeness,
            label: 'COMPLETENESS',
            backgroundColor: '#3498db',
            borderColor: '#3498db',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#3498db',
          },
          {
            data: consistency,
            label: 'CONSISTENCY',
            backgroundColor: '#00FFFF',
            borderColor: '#00FFFF',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#00FFFF',
          },
          {
            data: integrity,
            label: 'INTEGRITY',
            backgroundColor: '#7FFF00',
            borderColor: '#7FFF00',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#7FFF00',
          },
          {
            data: timelineness,
            label: 'TIMELINENESS',
            backgroundColor: '#a52a2a',
            borderColor: '#a52a2a',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: '#a52a2a',
          }
        ]
      };
      setDqiChartData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = accuracy;
      origindata.datasets[1].data = completeness;
      origindata.datasets[2].data = consistency;
      origindata.datasets[3].data = integrity;
      origindata.datasets[4].data = timelineness;
    }, [columnData]);
    return (
        <Card sx={{boxShadow:'0px 0px 30px 10px rgb(82 63 105 / 15%)'}}>
          <CardHeader
            avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
                {/* <BarChartIcon/> */}
                <LineChartIcon/>
            </Avatar>
            }
            title={<Typography variant='h5'>DQI Metric Percentage</Typography>}
            action={
              <Box sx={{width: "200px"}}>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Year</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={year}
                    onChange={evt => { setYear(evt.target.value); setMax(new Date(evt.target.value, month, 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {years.map((item)=>{
                      return <MenuItem key={item} value={item}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Month</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={month}
                    onChange={evt => { setMonth(evt.target.value); setMax(new Date(year,evt.target.value , 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {months.map((item, index)=>{
                      return <MenuItem key={index} value={index+1}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Box>
            }
          />
          <CardContent>
            <Grid 
              container 
              spacing={1} 
              direction={"column"} 
              justifyContent={'flex-start'} 
              alignItems={'center'}>
              <Grid item lg={3} style={{width:'inherit'}}>
                {/* <Bar */}
                <Line  
                  data={dqichartdata}
                  options={{
                    onClick: function(evt, element) {
                      if(element.length > 0) {
                        var filter = {}
                        if(element[0].datasetIndex == 0){
                          filter["type"]="ACCURACY";
                        }else if (element[1].datasetIndex == 1) {
                          filter["type"]="COMPLETENESS";
                        }else if (element[2].datasetIndex == 2) {
                          filter["type"]="CONSISTENCY";
                        }else if (element[3].datasetIndex == 3) {
                            filter["type"]="INTEGRITY";
                        }else{
                        filter["type"]="TIMELINENESS";
                        }
                        filter["date"] = dqichartdata.labels[element[0].index];
                        props.setFilter(filter);
                      }
                    },
                    plugins: {
                      tooltip: {
                        // Disable the on-canvas tooltip
                        enabled: false,
        
                        external: function(context) {
                            // Tooltip Element
                            let tooltipEl = document.getElementById('chartjs-tooltip');
        
                            // Create element on first render
                            if (!tooltipEl) {
                                tooltipEl = document.createElement('div');
                                tooltipEl.id = 'chartjs-tooltip';
                                tooltipEl.innerHTML = '<table></table>';
                                document.body.appendChild(tooltipEl);
                            }
        
                            // Hide if no tooltip
                            const tooltipModel = context.tooltip;
                            console.log({tooltipModel});
                            if (tooltipModel.opacity === 0) {
                                tooltipEl.style.opacity = 0;
                                return;
                            }
        
                            // Set caret Position
                            tooltipEl.classList.remove('above', 'below', 'no-transform');
                            if (tooltipModel.yAlign) {
                                tooltipEl.classList.add(tooltipModel.yAlign);
                            } else {
                                tooltipEl.classList.add('no-transform');
                            }
        
                            var accuracy = dqichartdata.datasets[0].data[tooltipModel.dataPoints[0].dataIndex];
                            var completeness = dqichartdata.datasets[1].data[tooltipModel.dataPoints[0].dataIndex];
                            var consistency = dqichartdata.datasets[2].data[tooltipModel.dataPoints[0].dataIndex];
                            var integrity = dqichartdata.datasets[3].data[tooltipModel.dataPoints[0].dataIndex];
                            var timelineness = dqichartdata.datasets[4].data[tooltipModel.dataPoints[0].dataIndex];
                            // Set Text
                            if (tooltipModel.body) {
                                const titleLines = tooltipModel.title || [];
        
                                let innerHtml = '<thead>';
        
                                titleLines.forEach(function(title) {
                                    innerHtml += '<tr><th>' + title + '</th></tr>';
                                });
                                innerHtml += '</thead><tbody>';
                                
                                let accuracyStyle = 'background:' + dqichartdata.datasets[0].backgroundColor;
                                accuracyStyle += '; border-color:' + dqichartdata.datasets[0].borderColor;
                                accuracyStyle += '; border-width: 2px';
                                accuracyStyle += '; width: 12px; height:12px; display: inline-block; margin-right:5px;';
                                let accuracySpan = '<span style="' + accuracyStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + accuracySpan +'ACCURACY: '+ accuracy + '</td></tr>';

                                let completenessStyle = 'background:' + dqichartdata.datasets[1].backgroundColor;
                                completenessStyle += '; border-color:' + dqichartdata.datasets[1].borderColor;
                                completenessStyle += '; border-width: 2px';
                                completenessStyle += '; border-width: 2px';
                                completenessStyle += '; width: 12px; height:12px; display: inline-block;  margin-right:5px;';
                                let completenessSpan = '<span style="' + completenessStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + completenessSpan +'COMPLETENESS: '+ completeness + '</td></tr>';

                                let consistencyStyle = 'background:' + dqichartdata.datasets[2].backgroundColor;
                                consistencyStyle += '; border-color:' + dqichartdata.datasets[2].borderColor;
                                consistencyStyle += '; border-width: 2px';
                                consistencyStyle += '; width: 12px; height:12px; display: inline-block; margin-right:5px;';
                                let consistencySpan = '<span style="' + consistencyStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + consistencySpan +'CONSISTENCY: '+ consistency + '</td></tr>';

                                let integrityStyle = 'background:' + dqichartdata.datasets[3].backgroundColor;
                                integrityStyle += '; border-color:' + dqichartdata.datasets[3].borderColor;
                                integrityStyle += '; border-width: 2px';
                                integrityStyle += '; border-width: 2px';
                                integrityStyle += '; width: 12px; height:12px; display: inline-block;  margin-right:5px;';
                                let integritySpan = '<span style="' + integrityStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + integritySpan +'INTEGRITY: '+ integrity + '</td></tr>';

                                let timelinenessStyle = 'background:' + dqichartdata.datasets[4].backgroundColor;
                                timelinenessStyle += '; border-color:' + dqichartdata.datasets[4].borderColor;
                                timelinenessStyle += '; border-width: 2px';
                                timelinenessStyle += '; border-width: 2px';
                                timelinenessStyle += '; width: 12px; height:12px; display: inline-block;  margin-right:5px;';
                                let timelinenessSpan = '<span style="' + timelinenessStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + timelinenessSpan +'TIMELINENESS: '+ timelineness + '</td></tr>';

                                innerHtml += '</tbody>';
        
                                let tableRoot = tooltipEl.querySelector('table');
                                tableRoot.innerHTML = innerHtml;
                            }
        
                            const position = context.chart.canvas.getBoundingClientRect();
                            // const bodyFont = Chart.helpers.toFont(tooltipModel.options.bodyFont);
        
                            // Display, position, and set styles for font
                            tooltipEl.style.opacity = 1;
                            tooltipEl.style.position = 'absolute';
                            tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
                            tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
                            // tooltipEl.style.font = bodyFont.string;
                            tooltipEl.style.padding = tooltipModel.padding + 'px ' + tooltipModel.padding + 'px';
                            tooltipEl.style.pointerEvents = 'none';
                        }
                      }
                    }
                  }}
                />
              </Grid>
              <Box style={{width:'inherit'}} sx={{ width: 600, paddingLeft:'20px', paddingRight:'20px', paddingTop:'20px'}}>
                  <Slider
                      getAriaLabel={() => 'Date Range'}
                      value={range}
                      onChange={changeFilter}
                      valueLabelDisplay="auto"
                      max={max}
                      getAriaValueText={valuetext}
                  />
              </Box>
            </Grid>
          </CardContent>
        </Card>
    );
  }

export default DqiChart;