import React, {useState, useEffect} from "react";
import { Bar} from "react-chartjs-2";
import {
    Card,
    CardHeader,
    Avatar,
    Typography,
    CardContent,
    Grid,
    FormControl,
    InputLabel,
    Select,
    MenuItem,
    Slider,
    Box
} from '@mui/material';
import {red,} from '@mui/material/colors';
import { ArcElement} from 'chart.js';
import Chart from 'chart.js/auto'
import BarChartIcon from '@mui/icons-material/BarChart';
import { useSelector, useDispatch } from 'react-redux';
import { getChartData, selectChartData } from "../../actions/dqmetricAction";
import { months } from '../../config/const';
Chart.register(ArcElement);
function valuetext(value) {
  return `$${value}`;
}
var origindata = {
  labels: ["Missing Data. Please check server..."],
  datasets: [
    {
      data: [],
      label: 'FAIL',
      backgroundColor: '#EC932F',
      borderColor: 'rgba(255,99,132,1)',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.4)',
      hoverBorderColor: 'rgba(255,99,132,1)',
    },
    {
      data: [],
      label: 'PASS',
      backgroundColor: '#3498db',
      borderColor: 'rgb(255,99,132)',
      borderWidth: 1,
      hoverBackgroundColor: 'rgba(255,99,132,0.2)',
      hoverBorderColor: 'rgb(255,99,132)',
    }
  ]
};
const MetricChartpercentage = (props) =>{
    const [range, setRange] = React.useState([1, 31]);
    const [max, setMax] = useState(31);
    const dispatch = useDispatch();
    const [year, setYear] =useState(new Date().getFullYear());
    const [month, setMonth] =useState(new Date().getMonth()+1);
    var years = [];
    for(var i = year-10; i < year+10 ; i++){
      years.push(i);
    }

    const[chartdata, setChartData] = useState(origindata);

    useEffect(() => {
      dispatch(getChartData({year:year, month:month, range:range}));
    },[year, month]);

    const columnData = useSelector(selectChartData);
    const changeFilter = (event, newValue) => {
      var from = new Date(year+"-"+month+"-"+newValue[0]).getTime();
      var to = new Date(year+"-"+month+"-"+newValue[1]).getTime();
      
      var label=[];
      var pass=[];
      var fail = [];
      for (var i = 0; i < columnData.length; i++){
        if(from <= new Date(columnData[i]._id).getTime() && new Date(columnData[i]._id).getTime()<= to){
          label.push(columnData[i]._id);
          pass.push(columnData[i].pass_count);
          fail.push(columnData[i].failed_count);
        }
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: pass,
            label: 'PASS',
            backgroundColor: '#EC932F',
            borderColor: 'rgb(255,99,132)',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.2)',
            hoverBorderColor: 'rgb(255,99,132)',
          },
          {
            data: fail,
            label: 'FAIL',
            backgroundColor: '#3498db',
            borderColor: 'rgba(255,99,132,1)',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: 'rgba(255,99,132,1)',
          }
        ]
      };
      setChartData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = pass;
      origindata.datasets[1].data = fail;
      setRange(newValue);
    };
    useEffect(() => {
      var label=[];
      var pass=[];
      var fail = [];
      for (var i = 0; i < columnData.length; i++){
        label.push(columnData[i]._id);
        pass.push(columnData[i].pass_count);
        fail.push(columnData[i].failed_count);
      }
      const statedata = {
        labels: label,
        datasets: [
          {
            data: pass,
            label: 'PASS',
            backgroundColor: '#EC932F',
            borderColor: 'rgb(255,99,132)',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.2)',
            hoverBorderColor: 'rgb(255,99,132)',
          },
          {
            data: fail,
            label: 'FAIL',
            backgroundColor: '#3498db',
            borderColor: 'rgba(255,99,132,1)',
            borderWidth: 1,
            hoverBackgroundColor: 'rgba(255,99,132,0.4)',
            hoverBorderColor: 'rgba(255,99,132,1)',
          }
        ]
      };
      setChartData(statedata);
      origindata.label = label;
      origindata.datasets[0].data = pass;
      origindata.datasets[1].data = fail;
    }, [columnData]);
    return (
        <Card sx={{ boxShadow:'0px 0px 30px 10px rgb(82 63 105 / 15%)'}}>
          <CardHeader
            avatar={
            <Avatar sx={{ bgcolor: red[500] }} aria-label="recipe">
                <BarChartIcon/>
            </Avatar>
            }
            title={<Typography variant='h5'>DQ Metric Chart</Typography>}
            action={
              <Box sx={{width: "200px"}}>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Year</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={year}
                    onChange={evt => { setYear(evt.target.value); setMax(new Date(evt.target.value, month, 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {years.map((item)=>{
                      return <MenuItem key={item} value={item}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
                <FormControl variant="standard" sx={{ m: 1, width: '40%' }}>
                  <InputLabel id="demo-simple-select-standard-label">Month</InputLabel>
                  <Select
                    required
                    labelId="demo-simple-select-standard-label"
                    id="demo-simple-select-standard"
                    value={month}
                    onChange={evt => { setMonth(evt.target.value); setMax(new Date(year,evt.target.value , 0).getDate()); }}
                    label="Type"
                    variant="standard"
                  >
                    {months.map((item, index)=>{
                      return <MenuItem key={index} value={index+1}>{item}</MenuItem>
                    })}
                  </Select>
                </FormControl>
              </Box>
            }
          />
          <CardContent>
            <Grid 
              container 
              spacing={1} 
              direction={"column"} 
              justifyContent={'flex-start'} 
              alignItems={'center'}>
              <Grid item lg={3} style={{width:'inherit'}}>
                <Bar
                  data={chartdata}
                  options={{
                    onClick: function(evt, element) {
                      if(element.length > 0) {
                        var filter = {}
                        if(element[0].datasetIndex == 1){
                          filter["type"]="FAIL";
                        }else{
                        filter["type"]="PASS";
                        }
                        filter["date"] = chartdata.labels[element[0].index];
                        props.setFilter(filter);
                      }
                    },
                    plugins: {
                      tooltip: {
                        // Disable the on-canvas tooltip
                        enabled: false,
        
                        external: function(context) {
                            // Tooltip Element
                            let tooltipEl = document.getElementById('chartjs-tooltip');
        
                            // Create element on first render
                            if (!tooltipEl) {
                                tooltipEl = document.createElement('div');
                                tooltipEl.id = 'chartjs-tooltip';
                                tooltipEl.innerHTML = '<table></table>';
                                document.body.appendChild(tooltipEl);
                            }
        
                            // Hide if no tooltip
                            const tooltipModel = context.tooltip;
                            if (tooltipModel.opacity === 0) {
                                tooltipEl.style.opacity = 0;
                                return;
                            }
        
                            // Set caret Position
                            tooltipEl.classList.remove('above', 'below', 'no-transform');
                            if (tooltipModel.yAlign) {
                                tooltipEl.classList.add(tooltipModel.yAlign);
                            } else {
                                tooltipEl.classList.add('no-transform');
                            }
        
                            var pass = chartdata.datasets[0].data[tooltipModel.dataPoints[0].dataIndex];
                            var fail = chartdata.datasets[1].data[tooltipModel.dataPoints[0].dataIndex];
                            // Set Text
                            if (tooltipModel.body) {
                                const titleLines = tooltipModel.title || [];
        
                                let innerHtml = '<thead>';
        
                                titleLines.forEach(function(title) {
                                    innerHtml += '<tr><th>' + title + '</th></tr>';
                                });
                                innerHtml += '</thead><tbody>';
                                
                                let passStyle = 'background:' + chartdata.datasets[0].backgroundColor;
                                passStyle += '; border-color:' + chartdata.datasets[0].borderColor;
                                passStyle += '; border-width: 2px';
                                passStyle += '; width: 12px; height:12px; display: inline-block; margin-right:5px;';
                                let passSpan = '<span style="' + passStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + passSpan +'PASS: '+ pass + '</td></tr>';

                                let failStyle = 'background:' + chartdata.datasets[1].backgroundColor;
                                failStyle += '; border-color:' + chartdata.datasets[1].borderColor;
                                failStyle += '; border-width: 2px';
                                failStyle += '; border-width: 2px';
                                failStyle += '; width: 12px; height:12px; display: inline-block;  margin-right:5px;';
                                let failSpan = '<span style="' + failStyle + '"></span>';
                                innerHtml += '<tr><td align="left">' + failSpan +'FAIL: '+ fail + '</td></tr>';

                                innerHtml += '</tbody>';
        
                                let tableRoot = tooltipEl.querySelector('table');
                                tableRoot.innerHTML = innerHtml;
                            }
        
                            const position = context.chart.canvas.getBoundingClientRect();
                            // const bodyFont = Chart.helpers.toFont(tooltipModel.options.bodyFont);
        
                            // Display, position, and set styles for font
                            tooltipEl.style.opacity = 1;
                            tooltipEl.style.position = 'absolute';
                            tooltipEl.style.left = position.left + window.pageXOffset + tooltipModel.caretX + 'px';
                            tooltipEl.style.top = position.top + window.pageYOffset + tooltipModel.caretY + 'px';
                            // tooltipEl.style.font = bodyFont.string;
                            tooltipEl.style.padding = tooltipModel.padding + 'px ' + tooltipModel.padding + 'px';
                            tooltipEl.style.pointerEvents = 'none';
                        }
                      }
                    }
                  }}
                />
              </Grid>
              <Box style={{width:'inherit'}} sx={{ width: 300, paddingLeft:'20px', paddingRight:'20px', paddingTop:'20px'}}>
                  <Slider
                      getAriaLabel={() => 'Date Range'}
                      value={range}
                      onChange={changeFilter}
                      valueLabelDisplay="auto"
                      max={max}
                      getAriaValueText={valuetext}
                  />
              </Box>
            </Grid>
          </CardContent>
        </Card>
    );
  }

export default MetricChartpercentage;