import { React, useEffect } from 'react';
import { useState } from 'react';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { toast, ToastContainer } from "react-toastify";


import {useDispatch } from 'react-redux';
import {
  addDqmetric
} from '../../actions/dqmetricAction';

export default function DqmetricDialog(props) {

  const dispatch = useDispatch();

  const [formData, setFormData] = useState(props.data);

  useEffect(()=>{
    setFormData(props.data)
  }, [props])
  const handleSave=()=>{
    var validRegex = /^[YN]/;
    if(formData.check_type === ""){
      toast.error("Check type Required!");
    }else if(formData.rule_cd === ""){
      toast.error("Rule cd Required!");
    // }else if(formData.product_nm === ""){
    //   toast.error("Product nm Required!");
    // }else if(formData.database_nm === ""){
    //   toast.error("Database nm Required!");
    }else if(formData.table_nm === ""){
      toast.error("Table nm Required!");
    }else if(formData.field_nm === ""){
      toast.error("Field nm Required!");
    // }else if(formData.system_nm === ""){
    //   toast.error("System nm Required!");
    }else if(formData.job_name === ""){
      toast.error("Job name Required!");
    }else if(formData.dq_type_nm === ""){
      toast.error("Dq type nm Required!");
    // }else if(formData.domain_owner === ""){
    //   toast.error("Domain owner Required!");
    // }else if(formData.alert_owner === ""){
    //   toast.error("Alert owner Required!");
    }else if(formData.trns_dt_key === ""){
      toast.error("Trns dt key Required!");
    }else if(formData.aggr_key === ""){
      toast.error("Aggr key Required!");
    }else if(formData.calc_type === ""){
      toast.error("Calc Type Required!");
    }else if(formData.metric_1_value === ""){
      toast.error("Metric 1 Required!");
    // }else if(formData.metric_2_value === ""){
    //   toast.error("Metric 2 Required!");
    }else if(formData.calc_value === ""){
      toast.error("Calc value Required!");
    }else if(formData.thrshld_cd === ""){
      toast.error("Threshold cd Required!");
    }else if(formData.inserted_ts === ""){
      toast.error("Inserted ts Required!");
    // }else if(formData.inserted_by === ""){
    //   toast.error("Inserted by Required!");
    }else if(formData.dqi_indicator === ""){
      toast.error("DQI Indicator Required!");
    }else if(formData.dq_check_description === ""){
      toast.error("DQ Check Description Required!");
    }else{
      dispatch(addDqmetric(formData));
      props.setOpen(false);
    }
  }
  return (
    <div>
      <Dialog open={props.open} onClose={()=>{props.setOpen(false)}}>
        <DialogTitle>DQ METRICS</DialogTitle>
        <DialogContent>
          <DialogContentText>
           DQ Metrics
          </DialogContentText>
          <TextField
            autoFocus
            required
            margin="dense"
            id="check_type"
            label="DQ Check Type"
            type="text"
            fullWidth
            variant="standard"
            value={formData.check_type}
            onChange={evt => { setFormData(f => ({ ...f, check_type: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="rule_cd"
            label="Rule Code"
            type="text"
            fullWidth
            variant="standard"
            value={formData.rule_cd}
            onChange={evt => { setFormData(f => ({ ...f, rule_cd: evt.target.value})) }}
          />
          {/* <TextField
            required
            margin="dense"
            id="product_nm"
            label="Product Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.product_nm}
            onChange={evt => { setFormData(f => ({ ...f, product_nm: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="database_nm"
            label="Database Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.database_nm}
            onChange={evt => { setFormData(f => ({ ...f, database_nm: evt.target.value})) }}
          /> */}
          <TextField
            autoFocus
            required
            margin="dense"
            id="table_nm"
            label="Table Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.table_nm}
            onChange={evt => { setFormData(f => ({ ...f, table_nm: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="field_nm"
            label="Column Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.field_nm}
            onChange={evt => { setFormData(f => ({ ...f, field_nm: evt.target.value})) }}
          />
          {/* <TextField
            required
            margin="dense"
            id="system_nm"
            label="System Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.system_nm}
            onChange={evt => { setFormData(f => ({ ...f, system_nm: evt.target.value})) }}
          /> */}
          <TextField
            required
            margin="dense"
            id="job_name"
            label="Job Name"
            type="text"
            fullWidth
            variant="standard"
            value={formData.job_name}
            onChange={evt => { setFormData(f => ({ ...f, job_name: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="dq_type_nm"
            label="DQ Category"
            type="text"
            fullWidth
            variant="standard"
            value={formData.dq_type_nm}
            onChange={evt => { setFormData(f => ({ ...f, dq_type_nm: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="dqi_indicator"
            label="DQI Indicator"
            type="text"
            fullWidth
            variant="standard"
            value={formData.dqi_indicator}
            onChange={evt => { setFormData(f => ({ ...f, dqi_indicator: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="dq_check_description"
            label="DQ Check Description"
            type="text"
            fullWidth
            variant="standard"
            value={formData.dq_check_description}
            onChange={evt => { setFormData(f => ({ ...f, dq_check_description: evt.target.value})) }}
          />
          {/* <TextField
            required
            margin="dense"
            id="domain_owner"
            label="Domain Owner"
            type="text"
            fullWidth
            variant="standard"
            value={formData.domain_owner}
            onChange={evt => { setFormData(f => ({ ...f, domain_owner: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="alert_owner"
            label="Alert Owner"
            type="text"
            fullWidth
            variant="standard"
            value={formData.alert_owner}
            onChange={evt => { setFormData(f => ({ ...f, alert_owner: evt.target.value})) }}
          /> */}
          <TextField
            required
            margin="dense"
            id="trns_dt_key"
            label="Transaction Date"
            type="text"
            fullWidth
            variant="standard"
            value={formData.trns_dt_key}
            onChange={evt => { setFormData(f => ({ ...f, trns_dt_key: evt.target.value})) }}
          />
          <TextField
            autoFocus
            required
            margin="dense"
            id="aggr_key"
            label="DQ Run Date"
            type="text"
            fullWidth
            variant="standard"
            value={formData.aggr_key}
            onChange={evt => { setFormData(f => ({ ...f, aggr_key: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="calc_type"
            label="DQ Measurement Type"
            type="text"
            fullWidth
            variant="standard"
            value={formData.calc_type}
            onChange={evt => { setFormData(f => ({ ...f, calc_type: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="metric_1_value"
            label="Expected value"
            type="text"
            fullWidth
            variant="standard"
            value={formData.metric_1_value}
            onChange={evt => { setFormData(f => ({ ...f, metric_1_value: evt.target.value})) }}
          />
          {/* <TextField
            required
            margin="dense"
            id="metric_2_value"
            label="Metric 2 Value"
            type="text"
            fullWidth
            variant="standard"
            value={formData.metric_2_value}
            onChange={evt => { setFormData(f => ({ ...f, metric_2_value: evt.target.value})) }}
          /> */}
          <TextField
            autoFocus
            required
            margin="dense"
            id="calc_value"
            label="Actual Value"
            type="text"
            fullWidth
            variant="standard"
            value={formData.calc_value}
            onChange={evt => { setFormData(f => ({ ...f, calc_value: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="thrshld_cd"
            label="Result"
            type="text"
            fullWidth
            variant="standard"
            value={formData.thrshld_cd}
            onChange={evt => { setFormData(f => ({ ...f, thrshld_cd: evt.target.value})) }}
          />
          <TextField
            required
            margin="dense"
            id="inserted_ts"
            label="Inserted TS"
            type="text"
            fullWidth
            variant="standard"
            value={formData.inserted_ts}
            onChange={evt => { setFormData(f => ({ ...f, inserted_ts: evt.target.value})) }}
          />
          {/* <TextField
            required
            margin="dense"
            id="inserted_by"
            label="Inserted By"
            type="text"
            fullWidth
            variant="standard"
            value={formData.inserted_by}
            onChange={evt => { setFormData(f => ({ ...f, inserted_by: evt.target.value})) }}
          /> */}
        </DialogContent>
        <DialogActions>
          <Button onClick={handleSave}>Save</Button>
          <Button onClick={()=>{props.setOpen(false)}}>Cancel</Button>
        </DialogActions>
      </Dialog>
      <ToastContainer autoClose={2000} />
    </div>
  );
}