import {React} from 'react';
import {Box, Container, Typography,} from '@mui/material';
const Present = () =>{
    return(
        <div>
            <Box sx={{
                height : '150px',
                paddingTop:'50px',
                justifyContent:"space-between",
                alignItems:"stretch" }} >
                    <Container>
                        <Typography
                            textAlign={'center'}
                            fontWeight={'light'}
                            fontFamily={'PT Serif, Georgia, serif'}
                            variant='h5'
                        >
                            
                        </Typography>
                        
                        <Typography
                            textAlign={'center'}
                            fontFamily={'PT Serif, Georgia, serif'}
                            variant='h6'
                        >
                        </Typography>
                    </Container>
            </Box>
        </div>
    );

}
export default Present;