import Response from '../services/response.service';
import Dqmetrics from '../models/dqmetricsModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';

function delDqmetric(req, res){
    Dqmetrics.remove({_id: req.body.id})
    .then((dqmetric)=>{
        res.json(Response.success(jwt.encode(dqmetric, timeSetting.secret)));
    })
    .catch((err)=>{
        console.log(err);
        res.json(Response.failure(err));
    })
}

function getAll(req, res){
    if(req.body.date && req.body.type){
        Dqmetrics.aggregate([
            {
                $addFields: {
                    format_date:{
                        $dateToString: {
                            date: "$inserted_ts",
                            format: "%Y-%m-%d"
                        }
                    }
                }
            },
            {
                $match:{
                    $and : [
                        {format_date:req.body.date},
                        {thrshld_cd:req.body.type}
                    ]
                }
            },
        ]).exec( (e, r) => {
            if(e) {
                console.log(e);
                res.json(Response.failure(e));
            }else{
                res.json(Response.success(jwt.encode(r, timeSetting.secret)));
            }
        });
    }else{
        Dqmetrics.find()
        .then((data)=>{
            res.json(Response.success(jwt.encode(data, timeSetting.secret)));
        }).catch((e)=>{
            res.json(Response.failure(e));
        })
    }
    
}
function getStatistic(req, res){
    var firstDay = new Date(req.body.year, req.body.month-1, 1);
    var lastDay = new Date(req.body.year, req.body.month, 0);
    Dqmetrics.aggregate([
        {
            $match:{
                inserted_ts:{
                    $gte:firstDay,
                    $lt:lastDay
                }
            }
        },
        {
            $group:{
                _id:  { $dateToString: {
                        date: "$inserted_ts",
                        format: "%Y-%m-%d"
                    }
                },
                pass_count:{$sum:{$cond: [ { $eq: [ "$thrshld_cd", "PASS" ] }, 1, 0 ]}},
                failed_count: {$sum: {$cond: [ { $eq: [ "$thrshld_cd", "FAIL" ] }, 1, 0 ]}}
            }
        },
        {
            $sort: {'_id':1}
        }
    ]).exec( (e, r) => {
        if(e) {
            console.log(e);
            res.json(Response.failure(e));
        }else{
            res.json(Response.success(jwt.encode(r, timeSetting.secret)));
        }
    });
}
function getDQI(req, res){
    var firstDay = new Date(req.body.year, req.body.month-1, 1);
    var lastDay = new Date(req.body.year, req.body.month, 0);
    Dqmetrics.aggregate([
        {
            $match:{
                inserted_ts:{
                    $gte:firstDay,
                    $lt:lastDay
                }
            }
        },
        {
            $group:{
                _id:  { $dateToString: {
                        date: "$inserted_ts",
                        format: "%Y-%m-%d"
                    }
                },
                accuracy_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator", "ACCURACY" ] }, 1, 0 ]}},
                completeness_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator", "COMPLETENESS" ] }, 1, 0 ]}},
                consistency_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator", "CONSISTENCY" ] }, 1, 0 ]}},
                integrity_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator", "INTEGRITY" ] }, 1, 0 ]}},
                timelineness_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator", "TIMELINENESS" ] }, 1, 0 ]}}
            }
        },
        {
            $sort: {'_id':1}
        }
    ]).exec( (e, r) => {
        if(e) {
            console.log(e);
            res.json(Response.failure(e));
        }else{
            res.json(Response.success(jwt.encode(r, timeSetting.secret)));
        }
    });
}
function getDQICount(req, res){
    var firstDay = new Date(req.body.year, req.body.month-1, 1);
    var lastDay = new Date(req.body.year, req.body.month, 0);
    Dqmetrics.aggregate([
        {
            $match:{
                inserted_ts:{
                    $gte:firstDay,
                    $lt:lastDay
                }
            }
        },
        {
            $group:{
                _id:  { $dateToString: {
                        date: "$inserted_ts",
                        format: "%Y-%m-%d"
                    }
                },
                accuracy_pass_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator_count", "ACCURACY_PASS" ] }, 1, 0 ]}},
                accuracy_fail_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator_count", "ACCURACY_FAIL" ] }, 1, 0 ]}},
                completeness_pass_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator_count", "COMPLETENESS_PASS" ] }, 1, 0 ]}},
                completeness_fail_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator_count", "COMPLETENESS_FAIL" ] }, 1, 0 ]}},
                consistency_pass_count:{$sum:{$cond: [ { $eq: [ "$dqi_indicator_count", "CONSISTENCY_PASS" ] }, 1, 0 ]}},
                consistency_fail_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator_count", "CONSISTENCY_FAIL" ] }, 1, 0 ]}},
                integrity_pass_count: {$sum:{$cond: [ { $eq: [ "$dqi_indicator_count", "INTEGRITY_PASS" ] }, 1, 0 ]}},
                integrity_fail_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator_count", "INTEGRITY_FAIL" ] }, 1, 0 ]}},
                timelineness_pass_count: {$sum:{$cond: [ { $eq: [ "$dqi_indicator_count", "TIMELINENESS_PASS" ] }, 1, 0 ]}},
                timelineness_fail_count: {$sum: {$cond: [ { $eq: [ "$dqi_indicator_count", "TIMELINENESS_FAIL" ] }, 1, 0 ]}}
            }
        },
        {
            $sort: {'_id':1}
        }
    ]).exec( (e, r) => {
        if(e) {
            console.log(e);
            res.json(Response.failure(e));
        }else{
            res.json(Response.success(jwt.encode(r, timeSetting.secret)));
        }
    });
}
function addDqmetric(req, res){
    if(req.body._id){
        Dqmetrics.findOneAndUpdate({_id: req.body._id}, req.body)
        .then((result)=>{
            res.json(Response.success(jwt.encode(result, timeSetting.secret)));
        })
        .catch((err) => {
            res.json(Response.failure(err));
        })
    }else{
        const dqmetricData = new Dqmetrics({
            check_type: req.body.check_type,
            rule_cd: req.body.rule_cd,
            // product_nm: req.body.product_nm,
            // database_nm: req.body.database_nm,
            table_nm: req.body.table_nm,
            field_nm: req.body.field_nm,
            // system_nm: req.body.system_nm,
            job_name: req.body.job_name,
            dq_type_nm: req.body.dq_type_nm,
            dqi_indicator: req.body.dqi_indicator,
            dq_check_description: req.body.dq_check_description,
            // domain_owner: req.body.domain_owner,
            // alert_owner: req.body.alert_owner,
            trns_dt_key: req.body.trns_dt_key,
            aggr_key: req.body.aggr_key,
            calc_type: req.body.calc_type,
            metric_1_value: req.body.metric_1_value,
            // metric_2_value: req.body.metric_2_value,
            calc_value: req.body.calc_value,
            thrshld_cd: req.body.thrshld_cd,
            inserted_ts: req.body.inserted_ts,
            // inserted_by: req.body.inserted_by
        });
        dqmetricData.save()
        .then((result)=>{
            res.json(Response.success(jwt.encode(result, timeSetting.secret)));
        })
        .catch((err)=>{
            res.json(Response.failure(err));
        });
    }
    
}

export default {
    delDqmetric,
    addDqmetric,
    getAll,
    getStatistic,
    getDQI,
    getDQICount
}

