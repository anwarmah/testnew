import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import Workflowstatuss from '../models/workflowstatusModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';
function delWorkflowstatus(req, res){
    Workflowstatuss.remove({_id: req.body.id})
    .then((workflowstatus)=>{
        res.json(Response.success(jwt.encode(workflowstatus, timeSetting.secret)));        
    })
    .catch((err)=>{
        res.json(Response.failure(err));
    })
}

function getAll(req, res){
    Workflowstatuss.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

function addWorkflowstatus(req, res){
    if(req.body._id){
        Workflowstatuss.findOneAndUpdate({_id: req.body._id}, req.body)
        .then((result)=>{
            res.json(Response.success(jwt.encode(result, timeSetting.secret)));
        })
        .catch((err) => {
            res.json(Response.failure(err));
        })
    }else{
        Workflowstatuss.find({rule_name:req.body.rule_name})
        .then((result) =>{
            console.log(result);
            if(result.length != 0){
                res.json(Response.failure(jwt.encode("rule_name already exist!", timeSetting.secret)));
            }else{
                const workflowstatusData = new Workflowstatuss({
                    workflow_name: req.body.workflow_name,
                    start_time: req.body.start_time,
                    average_runtime: req.body.average_runtime,
                    frequency: req.body.frequency,
                    duration: req.body.duration,
                    workflow_status: req.body.workflow_status,
                    sla: req.body.sla
                  });
                workflowstatusData.save()
                .then((result)=>{
                    res.json(Response.success(jwt.encode(result, timeSetting.secret)));
                })
                .catch((err)=>{
                    res.json(Response.failure(err));
                });
            }
        })
        .catch((err)=>{
            res.json(Response.failure(err));
        })
        
    }
    
}

export default {
    delWorkflowstatus,
    addWorkflowstatus,
    getAll
}