import ResourceCount from '../models/resourceModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';

function getAllResourceCount(req, res, next){
    const pipeLine = [
        {$sort: { createdAt: -1 } },
        {
          $group: {
            "_id": "$Region",
            "createdAt": {
                "$max": "$createdAt"
            },
            "doc": {
                "$first": "$$ROOT"
            }
          },
        }
    ];
    ResourceCount.aggregate(pipeLine).exec( (err, result) => {
        if(err){
            return next(err); 
        }else{
            var data = jwt.encode(result, timeSetting.secret);
            res.send(data);
        }
    })
}

export default {
    getAllResourceCount
}