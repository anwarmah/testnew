import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import Marketingdqs from '../models/marketingdqsModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';
function delMarketingdq(req, res){
    Marketingdqs.remove({_id: req.body.id})
    .then((marketingdq)=>{
        Events.remove({marketingdq: req.body.id})
        .then((event)=>{
            Calls.remove({marketingdq: req.body.id})
            .then((call)=>{
                res.json(Response.success(jwt.encode(call, timeSetting.secret)));
            })
        });
    })
    .catch((err)=>{
        res.json(Response.failure(err));
    })
}

function getAll(req, res){
    Marketingdqs.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

function addMarketingdq(req, res){
    if(req.body._id){
        Marketingdqs.findOneAndUpdate({_id: req.body._id}, req.body)
        .then((result)=>{
            res.json(Response.success(jwt.encode(result, timeSetting.secret)));
        })
        .catch((err) => {
            res.json(Response.failure(err));
        })
    }else{
        Marketingdqs.find({rule_name:req.body.rule_name})
        .then((result) =>{
            console.log(result);
            if(result.length != 0){
                res.json(Response.failure(jwt.encode("rule_name already exist!", timeSetting.secret)));
            }else{
                const marketingdqData = new Marketingdqs({
                    table_name: req.body.table_name,
                    column_name: req.body.column_name,
                    rule_name: req.body.rule_name,
                    custom_query_check: req.body.custom_query_check,
                    description: req.body.description
                  });
                marketingdqData.save()
                .then((result)=>{
                    res.json(Response.success(jwt.encode(result, timeSetting.secret)));
                })
                .catch((err)=>{
                    res.json(Response.failure(err));
                });
            }
        })
        .catch((err)=>{
            res.json(Response.failure(err));
        })
        
    }
    
}

export default {
    delMarketingdq,
    addMarketingdq,
    getAll
}

