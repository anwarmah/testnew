import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import s3bucketsize from '../models/s3sizeModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';

function getAlls3size(req, res){
    s3bucketsize.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

export default {
    getAlls3size,
}

