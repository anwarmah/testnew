import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import ec2Ami from '../models/amiModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';

function getAllec2ami(req, res){
    ec2Ami.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

export default {
    getAllec2ami,
}