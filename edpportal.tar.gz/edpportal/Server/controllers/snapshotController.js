import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import SnapShot from '../models/snapshotModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';

function getAllsnapshot(req, res){
    SnapShot.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

export default {
    getAllsnapshot,
}