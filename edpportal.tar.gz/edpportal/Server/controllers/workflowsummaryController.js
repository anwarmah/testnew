import Response from '../services/response.service';
// import Events from '../models/eventsModel';
import Workflowsummarys from '../models/workflowsummaryModel';
import jwt from 'jwt-simple';
import {timeSetting} from '../config/config';
function delWorkflowsummary(req, res){
    Workflowsummarys.remove({_id: req.body.id})
    .then((workflowsummary)=>{
        res.json(Response.success(jwt.encode(workflowsummary, timeSetting.secret)));        
    })
    .catch((err)=>{
        res.json(Response.failure(err));
    })
}

function getAll(req, res){
    Workflowsummarys.find()
    .then((data)=>{
        res.json(Response.success(jwt.encode(data, timeSetting.secret)));
    }).catch((e)=>{
        res,json(Response.failure(e));
    })
}

function addWorkflowsummary(req, res){
    if(req.body._id){
        Workflowsummarys.findOneAndUpdate({_id: req.body._id}, req.body)
        .then((result)=>{
            res.json(Response.success(jwt.encode(result, timeSetting.secret)));
        })
        .catch((err) => {
            res.json(Response.failure(err));
        })
    }else{
        Workflowsummarys.find({rule_name:req.body.rule_name})
        .then((result) =>{
            console.log(result);
            if(result.length != 0){
                res.json(Response.failure(jwt.encode("rule_name already exist!", timeSetting.secret)));
            }else{
                const workflowsummaryData = new Workflowsummarys({
                    workflow_name: req.body.workflow_name,
                    start_time: req.body.start_time,
                    average_runtime: req.body.average_runtime,
                    run_frequency: req.body.run_frequency,
                    job_dependency: req.body.job_dependency,
                    source_type: req.body.source_type,
                    source_connection: req.body.source_connection,
                    intermediate_table: req.body.intermediate_table,
                    ingestion_method: req.body.ingestion_method,
                    target: req.body.target
                  });
                workflowsummaryData.save()
                .then((result)=>{
                    res.json(Response.success(jwt.encode(result, timeSetting.secret)));
                })
                .catch((err)=>{
                    res.json(Response.failure(err));
                });
            }
        })
        .catch((err)=>{
            res.json(Response.failure(err));
        })
        
    }
    
}

export default {
    delWorkflowsummary,
    addWorkflowsummary,
    getAll
}