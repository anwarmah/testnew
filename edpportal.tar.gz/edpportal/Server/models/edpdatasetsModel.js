import mongoose from 'mongoose';
const edpdatasetsSchema = new mongoose.Schema({
    profile               : String,
    table_name            : String,
    description           : String,
    link                  : String,
    createdAt             : {
      type: Date,
      default: Date.now,
      required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('Edpdatasets', edpdatasetsSchema, 'edpdatasets');
