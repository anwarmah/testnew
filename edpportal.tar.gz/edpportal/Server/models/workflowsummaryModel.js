import mongoose from 'mongoose';
const workflowsummarysSchema = new mongoose.Schema({
    workflow_name : String,
    start_time: String,
    average_runtime: String,
    run_frequency: String,
    job_dependency: String,
    source_type: String,
    source_connection: String,
    intermediate_table: String,
    ingestion_method: String,
    target: String,
    createdAt              : {
      type: Date,
      default: Date.now,
      required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('Workflowsummarys', workflowsummarysSchema, 'workflowsummary');