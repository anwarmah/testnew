import mongoose from 'mongoose';

// model definition
const rcSchema = new mongoose.Schema({
    Region : String,
    Running_EC2: Number,
    Stopped_EC2: Number,
    Total_EC2: Number,
    Total_AMI: Number,
    Total_Snapshot: Number,
    Total_Lambda: Number,
    Total_S3: Number,
    All_used_resources: Number,
    Total_LB: Number,
    Total_sg: Number,
    Total_redshift: Number,
    Total_glue: Number,
    Total_dynamo_table: Number,
    Total_DocDB: Number,
    createdAt:  Date
});

export default mongoose.model('ResourceCount', rcSchema, 'resourceCount');