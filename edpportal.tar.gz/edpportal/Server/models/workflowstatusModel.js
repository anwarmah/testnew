import mongoose from 'mongoose';
const workflowstatussSchema = new mongoose.Schema({
    workflow_name : String,
    start_time: Number,
    average_runtime: Number,
    frequency: String,
    duration: String,
    workflow_status: String,
    sla: String,
    createdAt              : {
      type: Date,
      default: Date.now,
      required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('Workflowstatuss', workflowstatussSchema, 'workflowstatus');