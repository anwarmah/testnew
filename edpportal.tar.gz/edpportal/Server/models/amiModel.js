import mongoose from 'mongoose';

// model definition
const amiSchema = new mongoose.Schema({
    Region : String,
    Instance_AMI: String,
    Architecture: String,
    Creation_Date: String,
    Image_Location: String,
    Platform_Details: String,
    State: String,
    createdAt: {
        type: Date,
        default: Date.now,
        required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('ec2Ami', amiSchema, 'ec2ami');