import mongoose from 'mongoose';

// model definition
const s3Schema = new mongoose.Schema({
    DB_Instance_Name : String,
    DB_Type: String,
    DB_Storage: Number,
    DB_engine: String,
    DB_Engine_Address: String,
    DB_Engine_Port: Number,
    DB_Instance_Status: String,
    Preferred_Backup_Window: String,
    Backup_Retention_Period: Number,
    Availability_Zone: String,
    Preferred_Maintenance_Window: String, 
    createdAt: {
        type: Date,
        default: Date.now,
        required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('Rds', s3Schema, 'rds');