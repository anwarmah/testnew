import mongoose from 'mongoose';

// model definition
const s3Schema = new mongoose.Schema({
    s3_bucket_name : String,
    Bucket_Size: String,
    s3_last_modified_name: String,
    s3_last_modified_date: String,
    createdAt: {
        type: Date,
        default: Date.now,
        required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('s3bucketsize', s3Schema, 's3BucketSize');