import mongoose from 'mongoose';

// model definition
const dqmetricsSchema = new mongoose.Schema({
    check_type : String,
    rule_cd: String,
    // product_nm: String,
    // database_nm: String,
    table_nm: String,
    field_nm: String,
    // system_nm: String,
    job_name: String,
    dqi_indicator: String,
    dq_check_description: String,
    dqi_indicator_count: String,
    // domain_owner: String,
    // alert_owner: String,
    dq_type_nm: String,
    trns_dt_key: String,
    aggr_key: String,
    calc_type: String,
    metric_1_value: String,
    // metric_2_value: String,
    calc_value: String,
    thrshld_cd: String,
    inserted_ts: String,
    // inserted_by: String,
    createdAt: {
        type: Date,
        default: Date.now,
        required: 'Must have start date - default value is the created date'
    }
});

export default mongoose.model('Dqmetrics', dqmetricsSchema, 'dqmetrics');