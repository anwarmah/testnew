import express from 'express';
import dqmetricsCtrl from '../controllers/dqmetricsController'

const router = express.Router();

router.route('/addDqmetric')
    .post(dqmetricsCtrl.addDqmetric);

router.route('/getAll')
    .post(dqmetricsCtrl.getAll);

router.route('/delDqmetric')
    .post(dqmetricsCtrl.delDqmetric);
router.route('/getStatistic')
    .post(dqmetricsCtrl.getStatistic);
router.route('/getDQI')
    .post(dqmetricsCtrl.getDQI); 
router.route('/getDQICount')
    .post(dqmetricsCtrl.getDQICount); 
export default router;