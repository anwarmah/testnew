import express from 'express';
const router = express.Router();

// import authRoutes from './auth.route'
import eventRoutes from './event.route';
import contactRoutes from './contact.route';
import callRoutes from './call.route';
import ec2countRoutes from './ec2count.route';
import ec2instanceRoutes from './ec2instance.route';
import m2dRoutes from './m2d.route';
import y2dRoutes from './y2date.route';
import serviceRoutes from './service.route';
import faqRoutes from './faq.route';
import ticketRoutes from './ticket.route';
import edpdatasetRoutes from './edpdataset.route';
import edpdqRoutes from './edpdq.route';
import marketingdqRoutes from './marketingdq.route';
import dqmetricRoutes from './dqmetrics.route';
import rdsRoutes from './rds.route';
import s3Routes from './s3.route';
import snapshotRoutes from './snapshot.route';
import amiRoutes from './ami.route';
import resourceRoutes from './resource.route';
import workflowsummaryRoute from './workflowsummary.route';
import workflowstatusRoute from './workflowstatus.route';

// router.use('/auth', authRoutes);

router.use('/y2data', y2dRoutes);
router.use('/m2data', m2dRoutes);
router.use('/service', serviceRoutes);

router.use('/ec2count', ec2countRoutes);
router.use('/ec2instance', ec2instanceRoutes);

router.use('/event', eventRoutes);

router.use('/contact', contactRoutes);

router.use('/call', callRoutes);

router.use('/faq', faqRoutes);

router.use('/ticket', ticketRoutes);

router.use('/edpdataset', edpdatasetRoutes);

router.use('/edpdq', edpdqRoutes);

router.use('/marketingdq', marketingdqRoutes);

router.use('/dqmetric', dqmetricRoutes);

router.use('/rds', rdsRoutes);

router.use('/resource', resourceRoutes);

router.use('/s3', s3Routes);

router.use('/ami', amiRoutes);

router.use('/snapshot', snapshotRoutes);

router.use('/workflowsummary', workflowsummaryRoute);

router.use('/workflowstatus', workflowstatusRoute);

export default router;