import express from 'express';
import rdsCtrl from '../controllers/rdsController'

const router = express.Router();

router.route('/getAllrds')
  .post(rdsCtrl.getAllrds);

export default router;