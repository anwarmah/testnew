import express from 'express';
import snapshotCtrl from '../controllers/snapshotController'

const router = express.Router();

router.route('/getAllsnapshot')
  .post(snapshotCtrl.getAllsnapshot);

export default router;