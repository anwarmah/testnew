import express from 'express';
import amiCtrl from '../controllers/amiController'

const router = express.Router();

router.route('/getAllec2ami')
  .post(amiCtrl.getAllec2ami);

export default router;