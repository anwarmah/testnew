import express from 'express';
import edpdatasetCtrl from '../controllers/edpdatasetController';

const router = express.Router();

router.route('/addEdpdataset')
  // .post(validate(paramValidation.login), passport.authenticate('local', { session: false }), budgetCtrl.getM2dDataByMonth);
  .post(edpdatasetCtrl.addEdpdataset);

router.route('/getAll')
  .post(edpdatasetCtrl.getAll);
  
router.route('/delEdpdataset')
  .post(edpdatasetCtrl.delEdpdataset);
  
export default router;