import express from 'express';
// import passport from 'passport';
// import validate from 'express-validation';
// import authCtrl from '../controllers/auth.controller';
// import authorization from '../services/authorization.service';
// import auth from '../services/Permissions/index';
import workflowsummaryCtrl from '../controllers/workflowsummaryController';

const router = express.Router();

router.route('/addWorkflowsummary')
  // .post(validate(paramValidation.login), passport.authenticate('local', { session: false }), budgetCtrl.getM2dDataByMonth);
  .post(workflowsummaryCtrl.addWorkflowsummary);

router.route('/getAll')
  .post(workflowsummaryCtrl.getAll);
  
router.route('/delWorkflowsummary')
  .post(workflowsummaryCtrl.delWorkflowsummary);
  
export default router;